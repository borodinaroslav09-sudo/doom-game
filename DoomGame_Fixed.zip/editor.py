from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.graphics import Color, Rectangle, Line
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
import json, os

class MapEditor(App):
    def build(self):
        Window.softinput_mode = 'pan'
        
        self.size_grid = 21
        self.grid = [[1 for _ in range(self.size_grid)] for _ in range(self.size_grid)]
        self.floor_z = [[0.0 for _ in range(self.size_grid)] for _ in range(self.size_grid)]
        self.wall_h = [[1.0 for _ in range(self.size_grid)] for _ in range(self.size_grid)]
        self.ceil_z = [[0.0 for _ in range(self.size_grid)] for _ in range(self.size_grid)]
        self.ramps = [[0 for _ in range(self.size_grid)] for _ in range(self.size_grid)]
        self.spawns = [] # Список точек спавна {'x': x, 'y': y}
        
        self.cursor_x = 10
        self.cursor_y = 10
        self.grid[10][10] = 0 
        self.current_mode = 1
        
        layout = BoxLayout(orientation='vertical')
        
        # --- ВЕРХНЯЯ ПАНЕЛЬ (Кисти, сетка 3x4) ---
        top = GridLayout(cols=3, size_hint_y=None, height=dp(180), spacing=2)
        tools = [
            ('СТЕНА', 1, "1.0", (0.5,0.5,0.5,1)),
            ('ПОЛ', 0, "0.0", (0.6,0.4,0.2,1)),
            ('СТУПЕНЬ', 2, "0.25", (0.8,0.7,0.5,1)),
            ('НАКЛОН', 5, "1.0", (0.3,0.9,0.3,1)),
            ('ЯМА', 3, "-0.5", (0.2,0.1,0.1,1)),
            ('ПОТОЛОК', 4, "2.0", (0.4,0.6,0.8,1)),
            ('ВОДА', 6, "-1.0", (0.2,0.4,0.9,1)),
            ('ТОКСИНЫ', 7, "-1.0", (0.2,0.9,0.2,1)),
            ('ЛАВА', 8, "-1.0", (0.9,0.1,0.1,1)),
            ('СПАВН', 9, "0.0", (1.0,0.8,0.0,1)) # Новая кисть
        ]
        for text, mode, val, color in tools:
            btn = Button(text=text, background_color=color, font_size='11sp')
            btn.bind(on_release=lambda x, m=mode, v=val: self.set_mode(m, v))
            top.add_widget(btn)
        layout.add_widget(top)
        
        # --- ЦЕНТРАЛЬНАЯ ПАНЕЛЬ (Холст) ---
        self.canvas_layout = BoxLayout(size_hint_y=1)
        self.canvas_layout.bind(pos=self.redraw, size=self.redraw)
        layout.add_widget(self.canvas_layout)
        
        # --- НИЖНЯЯ ПАНЕЛЬ (Управление) ---
        bottom_ctrl = BoxLayout(orientation='vertical', size_hint_y=None, height=dp(140), spacing=5)
        
        row1 = BoxLayout(size_hint_y=None, height=dp(50), spacing=10)
        row1.add_widget(Label(text="Выс/Глуб:", size_hint_x=0.25, font_size='16sp'))
        self.param_input = TextInput(text="1.0", multiline=False, font_size='24sp', size_hint_x=0.45)
        row1.add_widget(self.param_input)
        
        btn_apply = Button(text='ПОСТАВИТЬ', background_color=(0.2,0.8,0.2,1), font_size='14sp', size_hint_x=0.3)
        btn_apply.bind(on_release=self.apply_brush)
        row1.add_widget(btn_apply)
        bottom_ctrl.add_widget(row1)
        
        row2 = BoxLayout(size_hint_y=None, height=dp(50), spacing=2)
        btn_left = Button(text='<', font_size='24sp', size_hint_x=0.2)
        btn_left.bind(on_release=lambda x: self.move_cursor(-1, 0))
        row2.add_widget(btn_left)
        
        btn_up = Button(text='^', font_size='24sp', size_hint_x=0.2)
        btn_up.bind(on_release=lambda x: self.move_cursor(0, -1))
        row2.add_widget(btn_up)
        
        btn_down = Button(text='v', font_size='24sp', size_hint_x=0.2)
        btn_down.bind(on_release=lambda x: self.move_cursor(0, 1))
        row2.add_widget(btn_down)
        
        btn_right = Button(text='>', font_size='24sp', size_hint_x=0.2)
        btn_right.bind(on_release=lambda x: self.move_cursor(1, 0))
        row2.add_widget(btn_right)
        
        btn_menu = Button(text='НАСТРОЙКИ', background_color=(0.4,0.4,0.4,1), font_size='14sp', size_hint_x=0.3)
        btn_menu.bind(on_release=self.show_menu)
        row2.add_widget(btn_menu)
        
        bottom_ctrl.add_widget(row2)
        layout.add_widget(bottom_ctrl)
        
        Clock.schedule_once(self.redraw, 0.1)
        return layout

    def show_menu(self, instance):
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        size_row = BoxLayout(size_hint_y=None, height=dp(50), spacing=5)
        size_row.add_widget(Label(text="Размер (5-60):", size_hint_x=0.5, font_size='14sp'))
        self.size_input = TextInput(text=str(self.size_grid), multiline=False, font_size='20sp', size_hint_x=0.25)
        size_row.add_widget(self.size_input)
        
        btn_resize = Button(text='ОК', background_color=(0.8,0.6,0.2,1), font_size='16sp', size_hint_x=0.25)
        
        def do_resize(inst):
            try:
                new_size = int(self.size_input.text)
                if new_size < 5: new_size = 5
                if new_size > 60: new_size = 60
            except: return

            new_grid = [[1 for _ in range(new_size)] for _ in range(new_size)]
            new_floor_z = [[0.0 for _ in range(new_size)] for _ in range(new_size)]
            new_wall_h = [[1.0 for _ in range(new_size)] for _ in range(new_size)]
            new_ceil_z = [[0.0 for _ in range(new_size)] for _ in range(new_size)]
            new_ramps = [[0 for _ in range(new_size)] for _ in range(new_size)]

            copy_size = min(self.size_grid, new_size)
            for i in range(copy_size):
                for j in range(copy_size):
                    new_grid[i][j] = self.grid[i][j]
                    new_floor_z[i][j] = self.floor_z[i][j]
                    new_wall_h[i][j] = self.wall_h[i][j]
                    new_ceil_z[i][j] = self.ceil_z[i][j]
                    new_ramps[i][j] = self.ramps[i][j]

            self.grid = new_grid
            self.floor_z = new_floor_z
            self.wall_h = new_wall_h
            self.ceil_z = new_ceil_z
            self.ramps = new_ramps
            self.size_grid = new_size
            self.cursor_x = new_size // 2
            self.cursor_y = new_size // 2
            self.spawns = [] # Сбрасываем спавны при изменении размера
            self.redraw()
            popup.dismiss()

        btn_resize.bind(on_release=do_resize)
        size_row.add_widget(btn_resize)
        content.add_widget(size_row)
        
        file_row = BoxLayout(size_hint_y=None, height=dp(50), spacing=5)
        file_row.add_widget(Label(text="Имя файла:", size_hint_x=0.3, font_size='14sp'))
        self.name_input = TextInput(text="map_1", multiline=False, font_size='16sp', size_hint_x=0.7)
        file_row.add_widget(self.name_input)
        content.add_widget(file_row)
        
        btn_row = BoxLayout(size_hint_y=None, height=dp(60), spacing=10)
        
        btn_open = Button(text='ОТКРЫТЬ', background_color=(0.8,0.6,0.2,1), font_size='14sp')
        btn_open.bind(on_release=lambda x: [popup.dismiss(), self.open_file()])
        btn_row.add_widget(btn_open)
        
        btn_save = Button(text='СОХРАНИТЬ', background_color=(0.2,0.6,0.8,1), font_size='14sp')
        btn_save.bind(on_release=lambda x: [popup.dismiss(), self.save_as_file()])
        btn_row.add_widget(btn_save)
        
        content.add_widget(btn_row)
        
        btn_close = Button(text='ЗАКРЫТЬ', size_hint_y=None, height=dp(50), background_color=(0.8,0.2,0.2,1), font_size='14sp')
        content.add_widget(btn_close)
        
        popup = Popup(title='Настройки', content=content, size_hint=(0.9, 0.7))
        btn_close.bind(on_release=popup.dismiss)
        popup.open()

    def set_mode(self, mode, default_param):
        self.current_mode = mode
        self.param_input.text = default_param

    def move_cursor(self, dx, dy):
        self.cursor_x = max(0, min(self.size_grid-1, self.cursor_x + dx))
        self.cursor_y = max(0, min(self.size_grid-1, self.cursor_y + dy))
        self.redraw()

    def apply_brush(self, instance):
        try: val = float(self.param_input.text)
        except: val = 0.0
            
        if self.current_mode == 1:
            self.grid[self.cursor_y][self.cursor_x] = 1
            self.wall_h[self.cursor_y][self.cursor_x] = val
            self.ceil_z[self.cursor_y][self.cursor_x] = 0.0
            self.ramps[self.cursor_y][self.cursor_x] = 0
        elif self.current_mode == 0:
            self.grid[self.cursor_y][self.cursor_x] = 0
            self.floor_z[self.cursor_y][self.cursor_x] = 0.0
            self.ramps[self.cursor_y][self.cursor_x] = 0
        elif self.current_mode == 2:
            self.grid[self.cursor_y][self.cursor_x] = 0
            self.floor_z[self.cursor_y][self.cursor_x] = abs(val)
            self.ramps[self.cursor_y][self.cursor_x] = 0
        elif self.current_mode == 3:
            self.grid[self.cursor_y][self.cursor_x] = 3
            self.floor_z[self.cursor_y][self.cursor_x] = -abs(val)
            self.ramps[self.cursor_y][self.cursor_x] = 0
        elif self.current_mode == 4:
            self.grid[self.cursor_y][self.cursor_x] = 0
            self.ceil_z[self.cursor_y][self.cursor_x] = val
        elif self.current_mode == 5: 
            self.grid[self.cursor_y][self.cursor_x] = 0
            self.floor_z[self.cursor_y][self.cursor_x] = 0.0
            self.ramps[self.cursor_y][self.cursor_x] = 1
        elif self.current_mode == 6: # ВОДА
            self.grid[self.cursor_y][self.cursor_x] = 6
            self.floor_z[self.cursor_y][self.cursor_x] = -abs(val)
        elif self.current_mode == 7: # ТОКСИНЫ
            self.grid[self.cursor_y][self.cursor_x] = 7
            self.floor_z[self.cursor_y][self.cursor_x] = -abs(val)
        elif self.current_mode == 8: # ЛАВА
            self.grid[self.cursor_y][self.cursor_x] = 8
            self.floor_z[self.cursor_y][self.cursor_x] = -abs(val)
        elif self.current_mode == 9: # СПАВН
            # Спавн можно ставить только на пол (0)
            if self.grid[self.cursor_y][self.cursor_x] == 0:
                # Удаляем старый спавн в этой клетке, если есть
                self.spawns = [s for s in self.spawns if not (int(s['x']) == self.cursor_x and int(s['y']) == self.cursor_y)]
                # Добавляем новый
                self.spawns.append({'x': self.cursor_x + 0.5, 'y': self.cursor_y + 0.5})
        self.redraw()

    def redraw(self, *args):
        self.canvas_layout.canvas.clear()
        w = self.canvas_layout.width
        h = self.canvas_layout.height
        
        size = min(w, h) - dp(20)
        offset_x = (w - size) / 2
        offset_y = h - size - dp(5) 
        
        cell_size = size / self.size_grid
        
        with self.canvas_layout.canvas:
            Color(0.1, 0.1, 0.1, 1)
            Rectangle(pos=self.canvas_layout.pos, size=self.canvas_layout.size)
            
            for i in range(self.size_grid):
                for j in range(self.size_grid):
                    val = self.grid[i][j]
                    fz = self.floor_z[i][j]
                    cz = self.ceil_z[i][j]
                    rp = self.ramps[i][j]
                    
                    if val == 1: 
                        c = min(1.0, 0.3 + self.wall_h[i][j]*0.2)
                        Color(c, c, c, 1)
                    elif val == 3: 
                        Color(0.1, 0.05, 0.05, 1)
                    elif val == 6:
                        Color(0.2, 0.4, 0.9, 1)
                    elif val == 7:
                        Color(0.2, 0.9, 0.2, 1)
                    elif val == 8:
                        Color(0.9, 0.1, 0.1, 1)
                    elif rp == 1:
                        Color(0.3, 0.9, 0.3, 1)
                    elif val == 0:
                        if fz > 0.05:
                            Color(0.9, 0.8, 0.6, 1)
                        else:
                            Color(0.6, 0.4, 0.2, 1)
                    else:
                        Color(0.6, 0.4, 0.2, 1)
                    
                    Rectangle(pos=(offset_x + j*cell_size, offset_y + (self.size_grid - 1 - i)*cell_size), size=(cell_size-1, cell_size-1))
                    
                    # Рисуем точки спавна (желтые квадраты)
                    for s in self.spawns:
                        if int(s['x']) == j and int(s['y']) == i:
                            Color(1.0, 0.8, 0.0, 1) # Желтый
                            Rectangle(pos=(offset_x + j*cell_size + cell_size*0.25, offset_y + (self.size_grid - 1 - i)*cell_size + cell_size*0.25), size=(cell_size*0.5, cell_size*0.5))
                    
                    if cz > 0:
                        Color(0.2, 0.4, 0.8, 1)
                        Rectangle(pos=(offset_x + j*cell_size + cell_size*0.3, offset_y + (self.size_grid - 1 - i)*cell_size + cell_size*0.3), size=(cell_size*0.4, cell_size*0.4))
            
            Color(1, 0, 0, 1)
            Line(rectangle=(offset_x + self.cursor_x*cell_size, offset_y + (self.size_grid - 1 - self.cursor_y)*cell_size, cell_size, cell_size), width=2)

    def open_file(self):
        content = BoxLayout(orientation='vertical')
        file_chooser = FileChooserListView(path="/storage/emulated/0/Download/Browser")
        content.add_widget(file_chooser)
        
        btn_layout = BoxLayout(size_hint=(1, None), height=dp(50))
        open_btn = Button(text='ЗАГРУЗИТЬ', background_color=(0.2,0.8,0.2,1))
        cancel_btn = Button(text='ОТМЕНА', background_color=(0.8,0.2,0.2,1))
        btn_layout.add_widget(open_btn)
        btn_layout.add_widget(cancel_btn)
        content.add_widget(btn_layout)
        
        popup = Popup(title='Выберите карту', content=content, size_hint=(0.85, 0.85))
        
        def load_selected(inst):
            if file_chooser.selection:
                path = file_chooser.selection[0]
                if path.endswith(".json"):
                    try:
                        with open(path, 'r') as f:
                            data = json.load(f)
                            self.size_grid = len(data["map"])
                            self.grid = data["map"]
                            self.floor_z = data.get("floor_z", [[0.0]*self.size_grid for _ in range(self.size_grid)])
                            self.wall_h = data.get("wall_h", [[1.0]*self.size_grid for _ in range(self.size_grid)])
                            self.ceil_z = data.get("ceil_z", [[0.0]*self.size_grid for _ in range(self.size_grid)])
                            self.ramps = data.get("ramps", [[0]*self.size_grid for _ in range(self.size_grid)])
                            self.spawns = data.get("spawns", []) # Загружаем спавны
                            self.name_input.text = os.path.basename(path).replace(".json", "")
                            self.cursor_x = self.size_grid // 2
                            self.cursor_y = self.size_grid // 2
                            self.redraw()
                            popup.dismiss()
                    except Exception as e:
                        print(f"Ошибка: {e}")
        
        open_btn.bind(on_release=load_selected)
        cancel_btn.bind(on_release=popup.dismiss)
        popup.open()

    def save_as_file(self):
        name = self.name_input.text.strip()
        if not name: name = "map_1"
        if not name.endswith(".json"): name += ".json"
        
        content = BoxLayout(orientation='vertical')
        file_chooser = FileChooserListView(path=os.path.dirname(os.path.abspath(__file__)))
        content.add_widget(file_chooser)
        
        btn_layout = BoxLayout(size_hint=(1, None), height=dp(50))
        save_btn = Button(text='Сохранить сюд