#Pydroid run sdl2
# === ФИКС PYDROID: Config ДО импортов Kivy ===
from kivy.config import Config
try:
    Config.set('graphics', 'width', '800')
    Config.set('graphics', 'height', '400')
except Exception as e:
    print(f"Config error (ignored): {e}")

from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.scrollview import ScrollView
from functools import partial
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.graphics.texture import Texture
from kivy.graphics import Color, Rectangle, Ellipse, Line, Triangle, InstructionGroup
from kivy.clock import Clock
from kivy.core.window import Window
import math, random, json, os, socket, threading, queue

# === СИСТЕМА НИЗИН: базовый пол на 1.0, чтобы ямы (0.0) были ВЫШЕ нуля ===
BASE_FLOOR = 0.0

SAVE_PATH = os.path.join(os.path.expanduser("~"), "doom_save.json")
net_queue = queue.Queue()
disc_queue = queue.Queue()

def rot_x(p, a):
    x,y,z = p; c,s = math.cos(a), math.sin(a)
    return (x, y*c-z*s, y*s+z*c)
def rot_y(p, a):
    x,y,z = p; c,s = math.cos(a), math.sin(a)
    return (x*c+z*s, y, -x*s+z*c)

def generate_world(size, seed):
    random.seed(seed)
    m = [[1 for _ in range(size)] for _ in range(size)]
    z = [[BASE_FLOOR for _ in range(size)] for _ in range(size)]
    cx, cy = size // 2, size // 2
    rs = 9
    for i in range(cy - rs, cy + rs + 1):
        for j in range(cx - rs, cx + rs + 1):
            if 0 <= i < size and 0 <= j < size:
                m[i][j] = 0
    # песочные ступеньки
    z[cy][cx] = BASE_FLOOR + 0.2
    z[cy-1][cx] = BASE_FLOOR + 0.4
    for dy, dx in [(1,0), (-1,0), (0,1), (0,-1)]:
        ny, nx = cy+dy, cx+dx
        if 0 <= ny < size and 0 <= nx < size and z[ny][nx] == BASE_FLOOR:
            z[ny][nx] = BASE_FLOOR + 0.15
    # ямы
    for i in range(cy+3, cy+5):
        for j in range(cx+3, cx+5):
            if 0 <= i < size and 0 <= j < size:
                m[i][j] = 3
                z[i][j] = BASE_FLOOR - 0.5
    return m, z

def build_cell(MAP, FLOOR_Z):
    """Строит CELL из MAP/FLOOR_Z. walls = [N,S,E,W] (0/1)."""
    size = len(MAP)
    cell = [[{'floor': FLOOR_Z[i][j], 'walls': [0,0,0,0]} for j in range(size)] for i in range(size)]
    for i in range(size):
        for j in range(size):
            if MAP[i][j] == 1: continue
            if i > 0 and MAP[i-1][j] == 1: cell[i][j]['walls'][0] = 1
            if i < size-1 and MAP[i+1][j] == 1: cell[i][j]['walls'][1] = 1
            if j < size-1 and MAP[i][j+1] == 1: cell[i][j]['walls'][2] = 1
            if j > 0 and MAP[i][j-1] == 1: cell[i][j]['walls'][3] = 1
    return cell

class GameServer:
    def __init__(self, port, name):
        self.port = port; self.name = name; self.clients = []; self.running = False
        self.tcp = None; self.udp = None
        try:
            self.tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.tcp.bind(("0.0.0.0", port)); self.tcp.listen(5)
            self.running = True
        except Exception as e:
            print(f"TCP bind failed: {e}")
            return
        try:
            self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.udp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.udp.bind(("0.0.0.0", 5001))
        except Exception as e:
            print(f"UDP bind failed: {e}")
            self.udp = None
        threading.Thread(target=self.udp_loop, daemon=True).start()
        threading.Thread(target=self.accept_loop, daemon=True).start()
    def udp_loop(self):
        if self.udp is None: return
        while self.running:
            try:
                data, addr = self.udp.recvfrom(1024)
                if data == b"DISCOVER_DOOM":
                    self.udp.sendto(json.dumps({"name": self.name, "port": self.port}).encode(), addr)
            except: pass
    def accept_loop(self):
        while self.running:
            try:
                self.tcp.settimeout(0.5)
                try:
                    conn, addr = self.tcp.accept(); self.clients.append(conn)
                except socket.timeout: pass
            except: break
    def broadcast(self, msg):
        data = (json.dumps(msg) + "\n").encode()
        for c in list(self.clients):
            try: c.sendall(data)
            except:
                try: self.clients.remove(c)
                except: pass

class GameClient:
    def __init__(self, ip, port):
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(2.0)  # Ждем 2 секунды
        try:
            self.sock.connect((ip, port))
            self.sock.settimeout(None)  # После подключения убираем таймаут
        except Exception as e:
            print(f"ОШИБКА ПОДКЛЮЧЕНИЯ: {e}. Проверь IP и порт!")
            raise e
        self.buf = b""; self.send_queue = queue.Queue()
        threading.Thread(target=self.recv_loop, daemon=True).start()
        threading.Thread(target=self.send_loop, daemon=True).start()
    def send(self, msg): self.send_queue.put(msg)
    def send_loop(self):
        while self.running:
            try:
                msg = self.send_queue.get(timeout=0.1)
                self.sock.sendall((json.dumps(msg) + "\n").encode())
            except: pass
    def recv_loop(self):
        while self.running:
            try:
                data = self.sock.recv(8192)
                if not data: break
                self.buf += data
                while b"\n" in self.buf:
                    line, self.buf = self.buf.split(b"\n", 1)
                    net_queue.put(json.loads(line.decode()))
            except: break

def scan_servers():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1); s.settimeout(1.0)
    try:
        s.sendto(b"DISCOVER_DOOM", ("255.255.255.255", 5001))
        while True:
            try:
                data, addr = s.recvfrom(1024)
                info = json.loads(data.decode())
                disc_queue.put({"ip": addr[0], "port": info["port"], "name": info["name"]})
            except socket.timeout: break
    except: pass
    s.close()

class MainMenu(Screen):
    def __init__(self, app, **kw):
        super().__init__(**kw)
        with self.canvas:
            Color(0.1,0.1,0.15); Rectangle(pos=(0,0), size=Window.size)
        self.add_widget(Label(text="DOOM 2.5D", font_size='40sp', color=(0.8,0.2,0.2,1), pos_hint={'center_x':0.5,'center_y':0.8}))
        b1 = Button(text='ИГРАТЬ', size_hint=(0.4,0.15), pos_hint={'center_x':0.5,'center_y':0.5}, background_color=(0.2,0.6,0.2,1))
        b1.bind(on_release=lambda x: app.show_play_menu()); self.add_widget(b1)
        b2 = Button(text='НАСТРОЙКИ', size_hint=(0.4,0.15), pos_hint={'center_x':0.5,'center_y':0.3}, background_color=(0.2,0.2,0.6,1))
        b2.bind(on_release=lambda x: app.show_settings()); self.add_widget(b2)

class PlayModeScreen(Screen):
    def __init__(self, app, **kw):
        super().__init__(**kw)
        with self.canvas:
            Color(0.1,0.1,0.15); Rectangle(pos=(0,0), size=Window.size)
        self.add_widget(Label(text="ВЫБОР РЕЖИМА", font_size='30sp', color=(1,1,1,1), pos_hint={'center_x':0.5,'center_y':0.85}))
        b1 = Button(text='ОДИНОЧНАЯ ИГРА', size_hint=(0.5,0.15), pos_hint={'center_x':0.5,'center_y':0.55}, background_color=(0.2,0.6,0.2,1))
        b1.bind(on_release=lambda x: app.start_single()); self.add_widget(b1)
        b2 = Button(text='МУЛЬТИПЛЕЕР', size_hint=(0.5,0.15), pos_hint={'center_x':0.5,'center_y':0.35}, background_color=(0.2,0.2,0.6,1))
        b2.bind(on_release=lambda x: app.show_mp_menu()); self.add_widget(b2)
        b4 = Button(text='КАСТОМНАЯ КАРТА', size_hint=(0.5,0.15), pos_hint={'center_x':0.5,'center_y':0.15}, background_color=(0.6,0.2,0.2,1))
        b4.bind(on_release=lambda x: app.show_map_select()); self.add_widget(b4)
        b3 = Button(text='НАЗАД', size_hint=(0.4,0.1), pos_hint={'center_x':0.5,'center_y':0.02})
        b3.bind(on_release=lambda x: app.show_menu()); self.add_widget(b3)

class MultiplayerMenu(Screen):
    def __init__(self, app, **kw):
        super().__init__(**kw); self.app = app
        with self.canvas:
            Color(0.1,0.1,0.15); Rectangle(pos=(0,0), size=Window.size)
        self.add_widget(Label(text="МУЛЬТИПЛЕЕР", font_size='28sp', color=(1,1,1,1), pos_hint={'center_x':0.5,'center_y':0.92}))
        self.nick_input = TextInput(text=app.nick, multiline=False, size_hint=(0.4,0.07), pos_hint={'center_x':0.5,'center_y':0.8}, hint_text='Ник')
        self.add_widget(self.nick_input)
        self.add_widget(Label(text="Ник:", pos_hint={'x':0.05,'center_y':0.8}, size_hint=(0.1,0.05)))
        self.port_input = TextInput(text=str(app.port), multiline=False, size_hint=(0.3,0.07), pos_hint={'center_x':0.65,'center_y':0.68}, hint_text='Порт')
        self.add_widget(self.port_input)
        self.add_widget(Label(text="Порт:", pos_hint={'x':0.4,'center_y':0.68}, size_hint=(0.1,0.05)))
        self.ip_input = TextInput(text=app.server_ip, multiline=False, size_hint=(0.3,0.07), pos_hint={'center_x':0.65,'center_y':0.56}, hint_text='IP')
        self.add_widget(Label(text="(для теста: 127.0.0.1)", pos_hint={'center_x':0.65,'center_y':0.51}, size_hint=(0.3,0.05), color=(1,1,0,0.7), font_size='10sp'))
        self.add_widget(self.ip_input)
        self.add_widget(Label(text="IP:", pos_hint={'x':0.4,'center_y':0.56}, size_hint=(0.1,0.05)))
        b1 = Button(text='СОЗДАТЬ СЕРВЕР', size_hint=(0.5,0.1), pos_hint={'center_x':0.5,'center_y':0.44}, background_color=(0.2,0.6,0.2,1))
        b1.bind(on_release=self.create_server); self.add_widget(b1)
        b2 = Button(text='ПОИСК СЕРВЕРОВ', size_hint=(0.5,0.1), pos_hint={'center_x':0.5,'center_y':0.32}, background_color=(0.2,0.2,0.6,1))
        b2.bind(on_release=self.search_servers); self.add_widget(b2)
        b3 = Button(text='ПОДКЛЮЧИТЬСЯ ПО IP', size_hint=(0.5,0.1), pos_hint={'center_x':0.5,'center_y':0.2}, background_color=(0.6,0.4,0.2,1))
        b3.bind(on_release=self.connect_ip); self.add_widget(b3)
        self.list_label = Label(text="", pos_hint={'center_x':0.5,'center_y':0.1}, size_hint=(0.8,0.15), color=(1,1,0,1), font_size='12sp', halign='center')
        self.add_widget(self.list_label)
        b4 = Button(text='НАЗАД', size_hint=(0.3,0.07), pos_hint={'center_x':0.15,'center_y':0.02})
        b4.bind(on_release=lambda x: app.show_play_menu()); self.add_widget(b4)
        Clock.schedule_interval(self.poll_found, 0.2)
        self.found = []
    def create_server(self, instance):
        self.app.nick = self.nick_input.text or "Player"
        try: self.app.port = int(self.port_input.text)
        except: self.app.port = 5555
        self.app.start_server_game()
    def connect_ip(self, instance):
        self.app.nick = self.nick_input.text or "Player"
        try: self.app.port = int(self.port_input.text)
        except: self.app.port = 5555
        ip = self.ip_input.text or "127.0.0.1"
        print(f"ПОДКЛЮЧАЕМСЯ К: {ip}:{self.app.port}")
        self.app.start_client_game(ip)
    def search_servers(self, instance):
        self.list_label.text = "Поиск..."
        self.found = []
        threading.Thread(target=scan_servers, daemon=True).start()
    def poll_found(self, dt):
        while not disc_queue.empty(): self.found.append(disc_queue.get())
        if self.found and not hasattr(self, 'btn_connect_found'):
            s = self.found[-1]
            self.btn_connect_found = Button(text=f"ВОЙТИ: {s['name']} ({s['ip']})", size_hint=(0.6, 0.08), pos_hint={'center_x':0.5,'center_y':0.12}, background_color=(0.2,0.8,0.2,1))
            self.btn_connect_found.bind(on_release=lambda x: self.connect_found(s))
            self.add_widget(self.btn_connect_found)
            self.list_label.text = f"Найден сервер: {s['name']}"

    def connect_found(self, s):
        self.ip_input.text = s['ip']
        self.port_input.text = str(s['port'])
        self.connect_ip(None)
    def on_enter(self):

        with self.canvas.before:
            Color(0.5, 0.7, 0.9, 1); Rectangle(pos=(0,0), size=Window.size)
        self.nick_input.text = self.app.nick
        self.port_input.text = str(self.app.port)
        self.ip_input.text = self.app.server_ip

class SettingsScreen(Screen):
    def __init__(self, app, **kw):
        super().__init__(**kw); self.app = app
        with self.canvas:
            Color(0.1,0.1,0.15); Rectangle(pos=(0,0), size=Window.size)
        self.add_widget(Label(text="НАСТРОЙКИ", font_size='26sp', color=(1,1,1,1), pos_hint={'center_x':0.5,'center_y':0.96}))
        self.add_widget(Label(text="Разрешение рендеринга:", pos_hint={'center_x':0.5,'center_y':0.86}, size_hint=(0.7,0.05), color=(1,1,1,1)))
        self.br = Button(text=f'{app.res}', size_hint=(0.4,0.08), pos_hint={'center_x':0.5,'center_y':0.79})
        self.br.bind(on_release=self.tr); self.add_widget(self.br)
        self.add_widget(Label(text="Экран (по центру):", pos_hint={'center_x':0.5,'center_y':0.69}, size_hint=(0.7,0.05), color=(1,1,1,1)))
        self.bs = Button(text=f'{app.screen_res}', size_hint=(0.4,0.08), pos_hint={'center_x':0.5,'center_y':0.62})
        self.bs.bind(on_release=self.ts); self.add_widget(self.bs)
        self.add_widget(Label(text="FPS:", pos_hint={'center_x':0.5,'center_y':0.52}, size_hint=(0.7,0.05), color=(1,1,1,1)))
        self.bf = Button(text=f'{app.fps_limit}', size_hint=(0.4,0.08), pos_hint={'center_x':0.5,'center_y':0.45})
        self.bf.bind(on_release=self.tf); self.add_widget(self.bf)
        self.add_widget(Label(text="HUD:", pos_hint={'center_x':0.5,'center_y':0.35}, size_hint=(0.7,0.05), color=(1,1,1,1)))
        self.bh = Button(text=f"{'ВКЛ' if app.hud_visible else 'ВЫКЛ'}", size_hint=(0.4,0.08), pos_hint={'center_x':0.5,'center_y':0.28})
        self.bh.bind(on_release=self.th); self.add_widget(self.bh)
        self.add_widget(Label(text="Масштаб HUD:", pos_hint={'center_x':0.5,'center_y':0.18}, size_hint=(0.7,0.05), color=(1,1,1,1)))
        self.bsc = Button(text=f"x{app.hud_scale}", size_hint=(0.4,0.08), pos_hint={'center_x':0.5,'center_y':0.11})
        self.bsc.bind(on_release=self.tsc); self.add_widget(self.bsc)
        bb = Button(text='НАЗАД', size_hint=(0.3,0.07), pos_hint={'center_x':0.5,'center_y':0.02}, background_color=(0.6,0.2,0.2,1))
        bb.bind(on_release=lambda x: app.show_menu()); self.add_widget(bb)
    def tr(self, i):
        rl = [(120,80),(160,100),(200,125),(240,150),(320,200),(400,250)]
        idx = rl.index(self.app.res) if self.app.res in rl else 0
        self.app.res = rl[(idx+1)%len(rl)]; self.br.text = f'{self.app.res}'
    def ts(self, i):
        rl = [(640,360),(800,450),(854,480),(960,540),(1024,576),(1280,720),(1366,768),(1600,900),(1920,1080),(2560,1440),(800,600),(1024,768),(1280,800),(1440,900),(1600,1200)]
        try: idx = rl.index(self.app.screen_res)
        except ValueError: idx = 0
        self.app.screen_res = rl[(idx+1)%len(rl)]; self.bs.text = f'{self.app.screen_res}'
        self.app.apply_screen_res()
    def tf(self, i):
        self.app.fps_limit = 15 if self.app.fps_limit == 30 else (60 if self.app.fps_limit == 15 else 30)
        self.bf.text = f'{self.app.fps_limit}'
    def th(self, i):
        self.app.hud_visible = not self.app.hud_visible; self.bh.text = f"{'ВКЛ' if self.app.hud_visible else 'ВЫКЛ'}"
    def tsc(self, i):
        scales = [1.0, 1.5, 2.0, 0.7]
        idx = scales.index(self.app.hud_scale) if self.app.hud_scale in scales else 0
        self.app.hud_scale = scales[(idx+1)%len(scales)]; self.bsc.text = f"x{self.app.hud_scale}"
class MapSelectScreen(Screen):
    def __init__(self, app, **kw):
        super().__init__(**kw); self.app = app
        with self.canvas:
            Color(0.1,0.1,0.15); Rectangle(pos=(0,0), size=Window.size)
        self.add_widget(Label(text="ВЫБОР КАРТЫ", font_size='30sp', color=(1,1,1,1), pos_hint={'center_x':0.5,'center_y':0.9}))
        
        self.scroll = ScrollView(size_hint=(0.8, 0.6), pos_hint={'center_x':0.5,'center_y':0.5})
        self.list_layout = BoxLayout(orientation='vertical', size_hint_y=None, spacing=5)
        self.list_layout.bind(minimum_height=self.list_layout.setter('height'))
        self.scroll.add_widget(self.list_layout)
        self.add_widget(self.scroll)
        
        b_back = Button(text='НАЗАД', size_hint=(0.4,0.1), pos_hint={'center_x':0.5,'center_y':0.1}, background_color=(0.6,0.2,0.2,1))
        b_back.bind(on_release=lambda x: app.show_play_menu()); self.add_widget(b_back)
        
    def on_enter(self):
        self.list_layout.clear_widgets()
        
        btn_browse = Button(text='ОБЗОР ПАМЯТИ...', size_hint_y=None, height=50, background_color=(0.8,0.4,0.1,1))
        btn_browse.bind(on_release=self.browse_file)
        self.list_layout.add_widget(btn_browse)
        
        import glob
        maps = glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "map_*.json"))
        if not maps:
            self.list_layout.add_widget(Label(text="Локальные карты не найдены", color=(1,1,0,1), size_hint_y=None, height=40))
            
        def make_callback(filepath):
            def callback(instance):
                print(f"ВЫБРАН ФАЙЛ: {filepath}")
                self.app.load_map(filepath)
            return callback

        for m in maps:
            name = os.path.basename(m)
            btn = Button(text=name, size_hint_y=None, height=50)
            btn.bind(on_release=make_callback(m))
            self.list_layout.add_widget(btn)

    def browse_file(self, instance):
        content = BoxLayout(orientation='vertical')
        file_chooser = FileChooserListView(path="/storage/emulated/0/Download/Browser")
        content.add_widget(file_chooser)
        
        btn_layout = BoxLayout(size_hint=(1, None), height=50)
        open_btn = Button(text='ЗАГРУЗИТЬ', background_color=(0.2,0.8,0.2,1))
        cancel_btn = Button(text='ОТМЕНА', background_color=(0.8,0.2,0.2,1))
        btn_layout.add_widget(open_btn)
        btn_layout.add_widget(cancel_btn)
        content.add_widget(btn_layout)
        
        popup = Popup(title='Выберите карту (.json)', content=content, size_hint=(0.85, 0.85))
        
        def load_selected(inst):
            if file_chooser.selection:
                path = file_chooser.selection[0]
                if path.endswith(".json"):
                    popup.dismiss()
                    print(f"ВЫБРАН ФАЙЛ (ОБЗОР): {path}")
                    self.app.load_map(path)
        
        open_btn.bind(on_release=load_selected)
        cancel_btn.bind(on_release=popup.dismiss)
        popup.open()

class GameScreen(Screen):
    def on_touch_down(self, touch):
        if self.eb.collide_point(*touch.pos) or self.chat_input.collide_point(*touch.pos):
            return super().on_touch_down(touch)
        if self.is_running and not self.spawn_menu_visible:
            try:
                return self.otd(Window, touch)
            except Exception as e:
                print(f"otd error: {e}")
        return super().on_touch_down(touch)

    def on_touch_move(self, touch):
        if self.is_running and not self.spawn_menu_visible:
            try:
                return self.otm(Window, touch)
            except Exception as e:
                print(f"otm error: {e}")
        return super().on_touch_move(touch)

    def on_touch_up(self, touch):
        if self.is_running and not self.spawn_menu_visible:
            try:
                return self.otu(Window, touch)
            except Exception as e:
                print(f"otu error: {e}")
        return super().on_touch_up(touch)

    def __init__(self, app, **kw):
        super().__init__(**kw); self.app = app; self.is_running = False
        self.floor_group = InstructionGroup()
        self.cube_group = InstructionGroup()
        self.ui_group = InstructionGroup()
        self.floor_group = InstructionGroup()
        self.cube_group = InstructionGroup()
        self.ui_group = InstructionGroup()
        
        # Жёсткое создание слоёв (снизу вверх)
        self.floor_group = InstructionGroup()
        self.cube_group = InstructionGroup()
        self.ui_group = InstructionGroup()
        self.net_client = None; self.net_server = None
        self.is_server_host = False; self.is_networked = False
        self.W, self.H = app.res
        self.NUM_RAYS = self.W // 2
        self.RAY_WIDTH = self.W // self.NUM_RAYS
        self.seed = random.randint(1, 99999)
        self.MAP, self.FLOOR_Z = generate_world(21, self.seed)
        self.MS = len(self.MAP)
        self.WALL_H = [[1.0 for _ in range(self.MS)] for _ in range(self.MS)]
        self.CEIL_Z = [[0.0 for _ in range(self.MS)] for _ in range(self.MS)]
        self.px = 10.5; self.py = 10.5
        self.angle = 0.0; self.pitch = 0.0
        self.base_eye = 0.5
        self.camera_z = BASE_FLOOR + self.base_eye
        self.jumping = False; self.jump_vy = 0.0
        self.mt = None; self.msx = 0; self.msy = 0; self.mdx = 0; self.mdy = 0
        self.lt = None; self.llx = 0; self.lly = 0
        self.shooting = False; self.recoil = 0.0
        self.buffer = bytearray(self.W*self.H*3); self.mv = memoryview(self.buffer)
        try:
            self.tex = Texture.create(size=(self.W,self.H), colorfmt='rgb')
        except Exception as e:
            print(f"Texture fallback: {e}")
            self.W, self.H = 128, 80
            self.NUM_RAYS = self.W // 2; self.RAY_WIDTH = self.W // self.NUM_RAYS
            self.buffer = bytearray(self.W*self.H*3); self.mv = memoryview(self.buffer)
            self.tex = Texture.create(size=(self.W,self.H), colorfmt='rgb')
        self.tex.mag_filter = 'nearest'; self.tex.flip_vertical()
        self.nick = app.nick
        self.cube_x = self.MS/2.0 + 2.0
        self.cube_y = self.MS/2.0 - 2.0
        self.cube_size = 0.15
        self.cube_z = self.FLOOR_Z[int(self.cube_y)][int(self.cube_x)] + self.cube_size
        self.cube_vx = 0.0; self.cube_vy = 0.0; self.cube_vz = 0.0
        self.cube_ax = 0.0; self.cube_ay = 0.0
        self.cube_mass = 2.0
        self.cube_holding = False
        self.held_spawned_cube = None
        self.wall_dists = [25.0] * self.NUM_RAYS
        self.spawned_cubes = []
        self.npcs = []
        self.chat_messages = []
        self.chat_timer = 0
        self.health = 100; self.dead = False
        self.drown_timer = 0
        self.damage_cooldown = 0
        self.ammo = 10; self.max_ammo = 10
        self.reloading = False; self.reload_timer = 0
        self.other_players = {}
        self.my_id = 0
        self.spawn_menu_visible = False
        with self.canvas.before:
            Color(0.5, 0.7, 0.9, 1); Rectangle(pos=(0,0), size=Window.size)
        with self.canvas:
            Color(1,1,1,1)
            self.rect = None
        self.wall_group = InstructionGroup()
        self.floor_group = InstructionGroup()
        self.cube_group = InstructionGroup()
        with self.canvas:
            Color(1,1,1,0.2); self.jb_bg = Ellipse(pos=(30,70), size=(140,140))
            Color(1,1,1,0.6); self.js = Ellipse(pos=(80,120), size=(40,40))
            Color(1,0.2,0.2,0.5); self.fb = Ellipse(pos=(Window.width-120,40), size=(80,80))
            Color(0.2,0.6,0.9,0.5); self.jump_btn_ellipse = Ellipse(pos=(Window.width/2-40, 150), size=(80,80))
            Color(0.3,0.9,0.3,0.5); self.pick_btn_ellipse = Ellipse(pos=(Window.width/2-40, 240), size=(80,80))
            Color(0.9,0.5,0.2,0.5); self.spawn_btn_ellipse = Ellipse(pos=(Window.width/2-40, 330), size=(80,80))
            Color(1,1,1,0.8)
            Line(points=[Window.width/2-10, Window.height/2, Window.width/2+10, Window.height/2], width=2)
            Line(points=[Window.width/2, Window.height/2-10, Window.width/2, Window.height/2+10], width=2)
            self.gc = Color(0.3,0.3,0.35); self.gb = Rectangle(pos=(Window.width/2-40,-20), size=(80,150))
            self.bc = Color(0.1,0.1,0.1); self.br2 = Rectangle(pos=(Window.width/2-10,100), size=(20,80))
        self.btn_respawn = Button(text='РЕСПАВН', size_hint=(0.4,0.1), pos_hint={'center_x':0.5,'center_y':0.5}, background_color=(0.2,0.8,0.2,1), font_size='20sp', opacity=0, disabled=True)
        self.btn_respawn.bind(on_release=self.respawn_player)
        self.add_widget(self.btn_respawn)
        self.eb = Button(text='В МЕНЮ', size_hint=(0.15,0.08), pos_hint={'right':0.98,'top':0.98}, background_color=(0.8,0.2,0.2,1), font_size='14sp')
        self.eb.bind(on_release=lambda x: app.show_menu()); self.add_widget(self.eb)
        self.fl = Label(text="", pos_hint={'center_x':0.5,'top':0.98}, size_hint=(None,None), size=(300,30), color=(0,1,0,1))
        self.add_widget(self.fl)
        self.jl = Label(text="JUMP", pos=(Window.width/2 - 30, 185), font_size='16sp', color=(1,1,1,1), bold=True)
        self.add_widget(self.jl)
        self.pl = Label(text="PICK", pos=(Window.width/2 - 28, 275), font_size='16sp', color=(1,1,1,1), bold=True)
        self.add_widget(self.pl)
        self.sl = Label(text="SPAWN", pos=(Window.width/2 - 35, 365), font_size='14sp', color=(1,1,1,1), bold=True)
        self.add_widget(self.sl)
        self.chat_label = Label(text="", pos_hint={'x': 0.02, 'top': 0.85}, size_hint=(0.4, 0.4), color=(1,1,0,1), font_size='14sp', halign='left', valign='top')
        self.chat_label.text_size = (Window.width*0.4, Window.height*0.4)
        self.add_widget(self.chat_label)
        self.chat_input = TextInput(text='', multiline=False, size_hint=(0.4, 0.08), pos_hint={'x': 0.02, 'y': 0.02}, font_size='14sp', background_color=(0,0,0,0.7), foreground_color=(0,1,0,1), hint_text='Введите текст...')
        self.chat_input.bind(on_text_validate=self.send_chat)
        self.chat_input.bind(focus=self.on_chat_focus)
        self.add_widget(self.chat_input)
        self.btn_spawn_dyn = Button(text='КУБ (ФИЗИКА)', size_hint=(0.3,0.08), pos_hint={'center_x':0.5,'center_y':0.7}, background_color=(0.2,0.8,0.2,1), opacity=0, disabled=True)
        self.btn_spawn_dyn.bind(on_release=lambda x: self.spawn_cube_at_front(True))
        self.add_widget(self.btn_spawn_dyn)
        self.btn_spawn_stat = Button(text='КУБ (СТАТИК)', size_hint=(0.3,0.08), pos_hint={'center_x':0.5,'center_y':0.6}, background_color=(0.9,0.9,0.9,1), color=(0,0,0,1), opacity=0, disabled=True)
        self.btn_spawn_stat.bind(on_release=lambda x: self.spawn_cube_at_front(False))
        self.add_widget(self.btn_spawn_stat)
        self.btn_spawn_npc = Button(text='СОЗДАТЬ NPC', size_hint=(0.3,0.08), pos_hint={'center_x':0.5,'center_y':0.5}, background_color=(0.8,0.2,0.2,1), opacity=0, disabled=True)
        self.btn_spawn_npc.bind(on_release=lambda x: self.spawn_npc_at_front())
        self.add_widget(self.btn_spawn_npc)
        self.btn_spawn_close = Button(text='ЗАКРЫТЬ', size_hint=(0.3,0.08), pos_hint={'center_x':0.5,'center_y':0.4}, background_color=(0.5,0.5,0.5,1), opacity=0, disabled=True)
        self.btn_spawn_close.bind(on_release=lambda x: self.toggle_spawn_menu(False))
        self.add_widget(self.btn_spawn_close)
        self.frames = 0; self.fps_display = 0; self.ltime = Clock.get_time()
        self.ce = None
        # --- ПОРЯДОК СЛОЁВ ---
        if not hasattr(self, 'ui_group'): self.ui_group = InstructionGroup()
        # ---------------------
        # --- СТРОГИЙ ПОРЯДОК СЛОЁВ ---
        self.canvas.add(self.floor_group)
        self.canvas.add(self.cube_group)
        self.canvas.add(self.ui_group)
        # -----------------------------
        self.update_ui_positions()
        
        # --- ЖЁСТКИЙ ПОРЯДОК СЛОЁВ ---
        # 1. Создаем группы (если их вдруг нет)
        if not hasattr(self, 'floor_group'): self.floor_group = InstructionGroup()
        if not hasattr(self, 'cube_group'): self.cube_group = InstructionGroup()
        if not hasattr(self, 'ui_group'): self.ui_group = InstructionGroup()
        
        # 2. 3D-мир (пол и кубы) - в основной слой (под виджетами)
        
        # 3. Интерфейс (джойстик, кнопки) - в canvas.after (ПОВЕРХ ВСЕГО)
                # -----------------------------
        # 3D мир и кубы (основной слой, под виджетами)
        # Интерфейс (джойстик, кнопки) - ПОВЕРХ ВСЕГО
        
    def on_window_resize(self, *args):
        self.update_ui_positions()

    def update_ui_positions(self):
        w = Window.width; h = Window.height; sc = self.app.hud_scale
        jx, jy = w*0.15, h*0.15; jr = int(w*0.09*sc)
        fx, fy = w - int(w*0.1*sc), h*0.15; fr = int(w*0.08*sc)
        jpx, jpy = w*0.5, h*0.75; jpr = int(w*0.06*sc)
        px_, py_ = w*0.5, h*0.55; pr_ = int(w*0.06*sc)
        sx_, sy_ = w*0.5, h*0.35; sr_ = int(w*0.06*sc)
        self.jb_bg.pos = (jx - jr, jy - jr); self.jb_bg.size = (jr*2, jr*2)
        self.js.pos = (jx - 20, jy - 20)
        self.fb.pos = (fx - fr, fy - fr); self.fb.size = (fr*2, fr*2)
        self.jump_btn_ellipse.pos = (jpx - jpr, jpy - jpr); self.jump_btn_ellipse.size = (jpr*2, jpr*2)
        self.pick_btn_ellipse.pos = (px_ - pr_, py_ - pr_); self.pick_btn_ellipse.size = (pr_*2, pr_*2)
        self.spawn_btn_ellipse.pos = (sx_ - sr_, sy_ - sr_); self.spawn_btn_ellipse.size = (sr_*2, sr_*2)
        self.jl.pos = (jpx - 30, jpy - 10)
        self.pl.pos = (px_ - 28, py_ - 10)
        self.sl.pos = (sx_ - 35, sy_ - 10)
        self.eb.size = (int(w*0.15*sc), int(h*0.08*sc))

    def toggle_spawn_menu(self, state):
        self.spawn_menu_visible = state
        op = 1 if state else 0; dis = not state
        self.btn_spawn_dyn.opacity = op; self.btn_spawn_dyn.disabled = dis
        self.btn_spawn_stat.opacity = op; self.btn_spawn_stat.disabled = dis
        self.btn_spawn_npc.opacity = op; self.btn_spawn_npc.disabled = dis
        self.btn_spawn_close.opacity = op; self.btn_spawn_close.disabled = dis

    def respawn_player(self, instance):
        self.health = 100
        self.dead = False
        self.drown_timer = 0
        self.damage_cooldown = 0
        
        # Ищем точки спавна на карте
        if getattr(self, 'spawns', None) and len(self.spawns) > 0:
            import random
            s = random.choice(self.spawns)
            self.px = s['x']
            self.py = s['y']
        else:
            self.px, self.py = self.get_safe_spawn()
            
        self.angle = 0.0
        self.pitch = 0.0
        self.camera_z = BASE_FLOOR + self.base_eye
        
        self.btn_respawn.opacity = 0
        self.btn_respawn.disabled = True
        self.chat_messages.append("ВЫ ВОЗРОДИЛИСЬ!")
        self.update_chat()

    def get_safe_spawn(self):
        cx, cy = int(self.MS / 2), int(self.MS / 2)
        for r in range(self.MS):
            for i in range(-r, r+1):
                for j in range(-r, r+1):
                    nx, ny = cx + i, cy + j
                    if 0 <= nx < self.MS and 0 <= ny < self.MS:
                        if self.MAP[ny][nx] == 0 and self.FLOOR_Z[ny][nx] >= 0.0:
                            return nx + 0.5, ny + 0.5
        return cx + 0.5, cy + 0.5

    def on_chat_focus(self, instance, value):
        if value:
            if self.ce: self.ce.cancel(); self.is_running = False
        else:
            if self.chat_messages:
                self.update_chat(); self.chat_timer = 8.0
            self.is_running = True; self.ltime = Clock.get_time()
            self.ce = Clock.schedule_interval(self.update, 1.0/self.app.fps_limit)

    def send_chat(self, instance):
        txt = instance.text.strip()
        if not txt: return
        self.chat_messages.append(f"{self.nick}: {txt}")
        if self.is_networked:
            if self.net_client: self.net_client.send({"type": "chat", "nick": self.nick, "text": txt})
            elif self.net_server is not None: self.net_server.broadcast({"type": "chat", "nick": self.nick, "text": txt})
        else:
            self.chat_messages.append("Бот: Ок.")
        self.chat_input.text = ''
        self.update_chat(); self.chat_timer = 8.0

    def update_chat(self):
        self.chat_label.text = "\n".join(self.chat_messages[-6:])

    def spawn_cube_at_front(self, is_dynamic):
        self.toggle_spawn_menu(False)
        for dist in [2.5, 2.0, 1.5, 1.0]:
            sx = self.px + math.cos(self.angle) * dist
            sy = self.py + math.sin(self.angle) * dist
            if self.cube_can_enter(sx, sy):
                fl = self.FLOOR_Z[int(sy)][int(sx)]
                colors = [(1,1,1),(1,0.2,0.2),(0.2,1,0.2),(0.2,0.4,1),(1,1,0.2)]
                self.spawned_cubes.append({
                    'x': sx, 'y': sy, 'z': fl + 0.15,
                    'vx': 0, 'vy': 0, 'vz': 0, 'ax': 0, 'ay': 0,
                    'size': 0.15, 'color': random.choice(colors), 'dynamic': is_dynamic
                })
                self.chat_messages.append(f"Куб ({'Физ' if is_dynamic else 'Стат'}) создан")
                self.update_chat(); self.chat_timer = 3.0
                return
        self.chat_messages.append("Нет места")
        self.update_chat(); self.chat_timer = 3.0

    def spawn_npc_at_front(self):
        self.toggle_spawn_menu(False)
        for dist in [3.0, 2.5, 2.0, 1.5]:
            sx = self.px + math.cos(self.angle) * dist
            sy = self.py + math.sin(self.angle) * dist
            if self.cube_can_enter(sx, sy):
                colors = [(0.9,0.2,0.2), (0.2,0.9,0.2), (0.2,0.2,0.9), (0.9,0.9,0.2)]
                self.npcs.append({'x': sx, 'y': sy, 'health': 100, 'alive': True, 'color': random.choice(colors)})
                self.chat_messages.append("NPC создан")
                self.update_chat(); self.chat_timer = 3.0
                return
        self.chat_messages.append("Нет места")
        self.update_chat(); self.chat_timer = 3.0

    def load_or_create(self):
        if os.path.exists(SAVE_PATH):
            try:
                with open(SAVE_PATH, "r") as f:
                    data = json.load(f)
                    self.seed = data["seed"]; self.MAP = data["map"]; self.FLOOR_Z = data["floor_z"]
                    self.MS = len(self.MAP)
                    self.px = data["player"]["x"]; self.py = data["player"]["y"]
                    self.angle = data["player"]["angle"]; self.pitch = data["player"]["pitch"]
                    c = data["cube"]
                    self.cube_x, self.cube_y, self.cube_z = c["x"], c["y"], c["z"]
                    self.cube_ax, self.cube_ay = c["ax"], c["ay"]
                    self.cube_mass = c["mass"]; self.cube_size = c["size"]
                    self.CELL = build_cell(self.MAP, self.FLOOR_Z)
                    return
            except: pass
        self.seed = random.randint(1, 99999)
        self.MAP, self.FLOOR_Z = generate_world(21, self.seed)
        self.MS = len(self.MAP)
        self.WALL_H = [[1.0 for _ in range(self.MS)] for _ in range(self.MS)]
        self.CEIL_Z = [[0.0 for _ in range(self.MS)] for _ in range(self.MS)]

    def save_game(self):
        try:
            data = {"seed": self.seed, "map": self.MAP, "floor_z": self.FLOOR_Z,
                    "player": {"x": self.px, "y": self.py, "angle": self.angle, "pitch": self.pitch},
                    "cube": {"x": self.cube_x, "y": self.cube_y, "z": self.cube_z,
                             "ax": self.cube_ax, "ay": self.cube_ay,
                             "mass": self.cube_mass, "size": self.cube_size}}
            with open(SAVE_PATH, "w") as f: json.dump(data, f)
        except: pass
    def on_enter(self):
        self.is_running = True
        self.W, self.H = self.app.res
        self.NUM_RAYS = self.W // 2; self.RAY_WIDTH = self.W // self.NUM_RAYS
        self.buffer = bytearray(self.W*self.H*3); self.mv = memoryview(self.buffer)
        try:
            self.tex = Texture.create(size=(self.W,self.H), colorfmt='rgb')
        except Exception as e:
            print(f"Texture fallback: {e}")
            self.W, self.H = 128, 80
            self.NUM_RAYS = self.W // 2; self.RAY_WIDTH = self.W // self.NUM_RAYS
            self.buffer = bytearray(self.W*self.H*3); self.mv = memoryview(self.buffer)
            self.tex = Texture.create(size=(self.W,self.H), colorfmt='rgb')
        self.tex.mag_filter = 'nearest'; self.tex.flip_vertical()
        self.wall_dists = [25.0] * self.NUM_RAYS
        self.cube_group.clear()
        self.frames = 0; self.ltime = Clock.get_time()
        
        # --- ЗАГРУЗКА КАРТЫ ---
        if self.app.multiplayer_mode == "custom" and getattr(self.app, 'custom_map_path', None):
            self.is_networked = False; self.my_id = 0
            try:
                with open(self.app.custom_map_path, "r") as f:
                    data = json.load(f)
                    self.MAP = data["map"]
                    self.FLOOR_Z = data["floor_z"]
                    self.MS = len(self.MAP)
                    self.px = data["player"]["x"]
                    self.py = data["player"]["y"]
                    self.angle = data["player"]["angle"]
                    self.pitch = data["player"]["pitch"]
                    
                    self.RAMPS = data.get("ramps", [[0 for _ in range(self.MS)] for _ in range(self.MS)])
                    self.WALL_H = data.get("wall_h", [[1.0 for _ in range(self.MS)] for _ in range(self.MS)])
                    self.CEIL_Z = data.get("ceil_z", [[0.0 for _ in range(self.MS)] for _ in range(self.MS)])
                    
                    self.CELL = build_cell(self.MAP, self.FLOOR_Z)
                        
                self.chat_messages.append(f"ЗАГРУЖЕНА КАРТА: {os.path.basename(self.app.custom_map_path)}")
                
                # Сброс кнопки респавна при загрузке новой карты
                if hasattr(self, 'btn_respawn'):
                    self.btn_respawn.opacity = 0
                    self.btn_respawn.disabled = True
                self.dead = False
                
                # Загружаем точки спавна
                self.spawns = data.get("spawns", [])
                if self.spawns:
                    import random
                    s = random.choice(self.spawns)
                    self.px = s['x']
                    self.py = s['y']
                    
            except Exception as e:
                self.chat_messages.append(f"ОШИБКА ЗАГРУЗКИ: {e}")
                self.load_or_create()
        else:
            self.load_or_create()
            
        self.nick = self.app.nick
        self.other_players = {}; self.dead = False; self.health = 100
        self.npcs = []; self.spawned_cubes = []; self.held_spawned_cube = None
        self.toggle_spawn_menu(False)
        self.update_ui_positions()
        
        if self.app.multiplayer_mode == "server":
            self.is_networked = True; self.is_server_host = True
            try: self.net_server = GameServer(self.app.port, self.nick)
            except Exception as e:
                self.chat_messages.append(f"Сервер: {e}"); self.is_networked = False
            self.my_id = 0
            self.chat_messages.append(f"Сервер на порту {self.app.port}")
        elif self.app.multiplayer_mode == "client":
            self.is_networked = True; self.is_server_host = False
            try:
                self.net_client = GameClient(self.app.server_ip, self.app.port)
                self.net_client.send({"type": "join", "nick": self.nick})
                self.chat_messages.append(f"OK {self.app.server_ip}:{self.app.port}")
            except Exception as e:
                self.chat_messages.append(f"Ошибка: {e}"); self.is_networked = False
        elif self.app.multiplayer_mode != "custom":
            self.is_networked = False; self.my_id = 0
            
        self.update_chat()
        if self.ce: self.ce.cancel()
        self.ce = Clock.schedule_interval(self.update, 1.0/self.app.fps_limit)

    def on_leave(self):
        self.is_running = False
        if self.ce: self.ce.cancel()
        Window.unbind(on_touch_down=self.otd, on_touch_move=self.otm, on_touch_up=self.otu)
        self.save_game()
        if self.net_server: self.net_server.running = False; self.net_server = None
        if self.net_client: self.net_client.running = False; self.net_client = None
        self.is_networked = False
        self.app.multiplayer_mode = None

    def cube_can_enter(self, x, y):
        if not (0 <= int(x) < self.MS and 0 <= int(y) < self.MS): return False
        return self.MAP[int(y)][int(x)] != 1  # Блокируем только стены (1), ямы (3) проходимы

    def toggle_pickup(self):
        if getattr(self, 'held_spawned_cube', None):
            # Отпускаем спавн-куб
            c = self.held_spawned_cube
            c['vx'] = 0
            c['vy'] = 0
            c['vz'] = 0
            self.held_spawned_cube = None
            self.update_chat(); self.chat_timer = 3.0
            return

        if self.cube_holding:
            self.cube_holding = False
            pr = (self.pitch / (self.H / 2)) * (math.pi / 3)
            self.cube_vx = math.cos(self.angle) * 0.4 * math.cos(pr)
            self.cube_vy = math.sin(self.angle) * 0.4 * math.cos(pr)
            self.cube_vz = math.sin(pr) * 0.4 + 0.1
            self.update_chat(); self.chat_timer = 3.0
            return

        # Ищем ближайший спавн-куб
        best_dist = 1.8
        best_cube = None
        for c in self.spawned_cubes:
            d = math.hypot(c['x'] - self.px, c['y'] - self.py)
            if d < best_dist:
                best_dist = d
                best_cube = c
                
        if best_cube:
            self.held_spawned_cube = best_cube
            self.update_chat(); self.chat_timer = 3.0
            return

        # Если спавн-кубов рядом нет, проверяем главный куб
        if math.hypot(self.cube_x - self.px, self.cube_y - self.py) < 1.8:
            self.cube_holding = True
            self.cube_vx = 0; self.cube_vy = 0; self.cube_vz = 0
        self.update_chat(); self.chat_timer = 3.0

    def update_cube_physics(self, dt):
        if self.cube_holding:
            pr = (self.pitch / (self.H / 2)) * (math.pi / 3)
            self.cube_x = self.px + math.cos(self.angle) * 0.7 * math.cos(pr)
            self.cube_y = self.py + math.sin(self.angle) * 0.7 * math.cos(pr)
            self.cube_z = self.camera_z + math.sin(pr) * 0.7 - 0.1
            return
        self.cube_vz -= 9.8 * dt
        ncx = self.cube_x + self.cube_vx * dt
        ncy = self.cube_y + self.cube_vy * dt
        if self.cube_can_enter(ncx, self.cube_y): self.cube_x = ncx
        else: self.cube_vx = -self.cube_vx * 0.5
        if self.cube_can_enter(self.cube_x, ncy): self.cube_y = ncy
        else: self.cube_vy = -self.cube_vy * 0.5
        ncz = self.cube_z + self.cube_vz * dt
        fl = self.FLOOR_Z[int(self.cube_y)][int(self.cube_x)] + self.cube_size
        if ncz < fl:
            ncz = fl
            if self.cube_vz < 0:
                self.cube_vz = -self.cube_vz * 0.6
                if abs(self.cube_vz) < 0.4: self.cube_vz = 0
        self.cube_z = ncz
        if self.cube_z <= fl + 0.01:
            self.cube_vx *= 0.97; self.cube_vy *= 0.97
            if abs(self.cube_vx) < 0.05: self.cube_vx = 0
            if abs(self.cube_vy) < 0.05: self.cube_vy = 0

    def update_spawned_cubes(self, dt):
        for c in self.spawned_cubes:
            if c is getattr(self, 'held_spawned_cube', None):
                pr = (self.pitch / (self.H / 2)) * (math.pi / 3)
                c['x'] = self.px + math.cos(self.angle) * 0.7 * math.cos(pr)
                c['y'] = self.py + math.sin(self.angle) * 0.7 * math.cos(pr)
                c['z'] = self.camera_z + math.sin(pr) * 0.7 - 0.1
                continue

            if not c['dynamic']: continue
            
            c['vz'] -= 9.8 * dt
            ncx = c['x'] + c['vx'] * dt
            ncy = c['y'] + c['vy'] * dt
            
            if self.cube_can_enter(ncx, c['y']): c['x'] = ncx
            else: c['vx'] = -c['vx'] * 0.5
            if self.cube_can_enter(c['x'], ncy): c['y'] = ncy
            else: c['vy'] = -c['vy'] * 0.5
            
            ncz = c['z'] + c['vz'] * dt
            fl = self.FLOOR_Z[int(c['y'])][int(c['x'])] + c['size']
            
            for other in self.spawned_cubes:
                if other is c: continue
                if abs(c['x'] - other['x']) < c['size'] * 1.1 and abs(c['y'] - other['y']) < c['size'] * 1.1:
                    if c['z'] >= other['z'] + other['size'] - 0.05:
                        fl = max(fl, other['z'] + other['size'] + c['size'])
                        
            if ncz < fl:
                ncz = fl
                if c['vz'] < 0:
                    c['vz'] = -c['vz'] * 0.6
                    if abs(c['vz']) < 0.4: c['vz'] = 0
            c['z'] = ncz
            
            if c['z'] <= fl + 0.05:
                c['vx'] *= 0.5; c['vy'] *= 0.5
                if abs(c['vx']) < 0.1: c['vx'] = 0
                if abs(c['vy']) < 0.1: c['vy'] = 0

    def can_move(self, nx, ny):
        if not (0 <= int(nx) < self.MS and 0 <= int(ny) < self.MS): return False
        if self.MAP[int(ny)][int(nx)] == 1: return False
        tf = self.FLOOR_Z[int(ny)][int(nx)]
        
        # Коллизия с главным кубом
        if not self.cube_holding:
            if abs(self.cube_x - nx) < self.cube_size * 1.4 and abs(self.cube_y - ny) < self.cube_size * 1.4:
                ct = self.cube_z + self.cube_size
                pb = self.camera_z - self.base_eye
                if pb < ct - 0.05 and not self.jumping: return False
                tf = max(tf, ct)
                
        # Коллизия со спавн-кубами и ТОЛКАНИЕ
        for c in self.spawned_cubes:
            if c is getattr(self, 'held_spawned_cube', None): continue
            if abs(c['x'] - nx) < c['size'] * 1.4 and abs(c['y'] - ny) < c['size'] * 1.4:
                ct = c['z'] + c['size']
                pb = self.camera_z - self.base_eye
                if pb < ct - 0.05 and not self.jumping:
                    if c['dynamic']:
                        # Толкаем куб (ограниченная скорость)
                        c['vx'] = math.cos(self.angle) * 0.5
                        c['vy'] = math.sin(self.angle) * 0.5
                    return False
                tf = max(tf, ct)
                
        if self.jumping: return True
        return tf - self.FLOOR_Z[int(self.py)][int(self.px)] <= 0.2

    def do_jump(self):
        if not self.jumping:
            self.jumping = True; self.jump_vy = 0.25

    def try_hit_objects(self):
        cw = self.wall_dists[self.NUM_RAYS // 2]
        for npc in self.npcs:
            if not npc["alive"]: continue
            dx = npc["x"] - self.px; dy = npc["y"] - self.py
            dist = math.hypot(dx, dy)
            if dist > 20: continue
            ang = math.atan2(dy, dx)
            diff = abs((ang - self.angle + math.pi) % (2*math.pi) - math.pi)
            if diff < 0.15 and dist < cw:
                npc["health"] -= 34
                if npc["health"] <= 0: npc["alive"] = False
                return True
        for c in self.spawned_cubes:
            if not c["dynamic"]: continue
            dx = c["x"] - self.px; dy = c["y"] - self.py
            dist = math.hypot(dx, dy)
            if dist > 1.5: continue
            ang = math.atan2(dy, dx)
            diff = abs((ang - self.angle + math.pi) % (2*math.pi) - math.pi)
            if diff < 0.3 and dist < cw:
                pr = (self.pitch / (self.H / 2)) * (math.pi / 3)
                fv = 6.0
                c["vx"] += math.cos(self.angle) * fv * math.cos(pr)
                c["vy"] += math.sin(self.angle) * fv * math.cos(pr)
                c["vz"] += math.sin(pr) * fv + 1.0
                return True
        return False

    def otd(self, w, t):
        if not self.is_running: return False
        if getattr(self, 'dead', False): return False
        if getattr(self, 'dead', False): return False
        if self.spawn_menu_visible: return False
        if self.eb.collide_point(*t.pos) or self.chat_input.collide_point(*t.pos): return False
        ww = Window.width
        if math.hypot(t.x - ww*0.5, t.y - Window.height*0.75) < 60: self.do_jump(); return True
        if math.hypot(t.x - ww*0.5, t.y - Window.height*0.55) < 60: self.toggle_pickup(); return True
        if math.hypot(t.x - ww*0.5, t.y - Window.height*0.35) < 60: self.toggle_spawn_menu(True); return True
        if math.hypot(t.x - (ww - int(ww*0.1*self.app.hud_scale)), t.y - Window.height*0.15) < int(ww*0.08*self.app.hud_scale):
            if self.reloading:
                return True
            
            if self.ammo > 0:
                self.ammo -= 1
                self.shooting = True
                dcx = self.cube_x - self.px
                dcy = self.cube_y - self.py
                if math.hypot(dcx, dcy) < 1.5:
                    pr = (self.pitch / (self.H / 2)) * (math.pi / 3)
                    fv = 8.0 / self.cube_mass
                    self.cube_vx = math.cos(self.angle) * fv * math.cos(pr)
                    self.cube_vy = math.sin(self.angle) * fv * math.cos(pr)
                    self.cube_vz = math.sin(pr) * fv + 1.0
                self.try_hit_objects()
            else:
                # Включаем перезарядку ТОЛЬКО если еще не перезаряжаемся
                if not self.reloading:
                    self.reloading = True
                    self.reload_timer = 1.5
                    self.chat_messages.append("Перезарядка...")
                    self.update_chat()
            return True
            
            if self.ammo > 0:
                self.ammo -= 1
                self.shooting = True
                dcx = self.cube_x - self.px
                dcy = self.cube_y - self.py
                if math.hypot(dcx, dcy) < 1.5:
                    pr = (self.pitch / (self.H / 2)) * (math.pi / 3)
                    fv = 8.0 / self.cube_mass
                    self.cube_vx = math.cos(self.angle) * fv * math.cos(pr)
                    self.cube_vy = math.sin(self.angle) * fv * math.cos(pr)
                    self.cube_vz = math.sin(pr) * fv + 1.0
                self.try_hit_objects()
            else:
                # Включаем перезарядку ТОЛЬКО если еще не перезаряжаемся
                if not self.reloading:
                    self.reloading = True
                    self.reload_timer = 1.5
                    self.chat_messages.append("Перезарядка...")
                    self.update_chat()
            return True
            
            if self.ammo > 0:
                self.ammo -= 1
                self.shooting = True
                dcx = self.cube_x - self.px
                dcy = self.cube_y - self.py
                if math.hypot(dcx, dcy) < 1.5:
                    pr = (self.pitch / (self.H / 2)) * (math.pi / 3)
                    fv = 8.0 / self.cube_mass
                    self.cube_vx = math.cos(self.angle) * fv * math.cos(pr)
                    self.cube_vy = math.sin(self.angle) * fv * math.cos(pr)
                    self.cube_vz = math.sin(pr) * fv + 1.0
                self.try_hit_objects()
            else:
                # Включаем перезарядку ТОЛЬКО если еще не перезаряжаемся
                if not self.reloading:
                    self.reloading = True
                    self.reload_timer = 1.5
                    self.chat_messages.append("Перезарядка...")
                    self.update_chat()
            return True
        if t.x < ww/2:
            self.mt = t.uid; self.msx = t.x; self.msy = t.y
        else:
            self.lt = t.uid; self.llx = t.x; self.lly = t.y
        return True

    def otm(self, w, t):
        if not self.is_running: return False
        if self.spawn_menu_visible: return False
        try:
            if t.uid == self.mt:
                dx = t.x - self.msx; dy = t.y - self.msy
                d = math.hypot(dx, dy)
                r = int(Window.width*0.09*self.app.hud_scale)
                if d > r: dx = dx/d*r; dy = dy/d*r
                self.mdx = dx/r; self.mdy = dy/r
                self.js.pos = (Window.width*0.15 + dx - 20, Window.height*0.15 + dy - 20)
            elif t.uid == self.lt:
                ddx = t.x - self.llx; ddy = t.y - self.lly
                self.angle += ddx * 0.008
                self.pitch += ddy * 0.5
                self.pitch = max(-self.H//2, min(self.H//2, self.pitch))
                self.llx = t.x; self.lly = t.y
        except: pass
        return True

    def otu(self, w, t):
        if not self.is_running: return False
        ww = Window.width
        if math.hypot(t.x - (ww - int(ww*0.1*self.app.hud_scale)), t.y - Window.height*0.15) < int(ww*0.08*self.app.hud_scale):
            self.shooting = False
        if t.uid == self.mt:
            self.mt = None; self.mdx = 0; self.mdy = 0
            self.js.pos = (ww*0.15 - 20, Window.height*0.15 - 20)
        elif t.uid == self.lt: self.lt = None
        return True

    def draw_cube_3d(self, cx, cy, cz, ax, ay, s, colors):
        verts = [(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
        faces = [(0,1,2),(0,2,3),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(0,3,7),(0,7,4),(1,2,6),(1,6,5)]
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        rv = [rot_y(rot_x(v, ax), ay) for v in verts]
        pj = []
        for v in rv:
            wx = cx + v[0]; wy = cy + v[1]; wz = cz + v[2]
            dx = wx - self.px; dy = wy - self.py
            d = dx * cos_a + dy * sin_a
            l = -dx * sin_a + dy * cos_a
            if d < 0.15: return
            bx = self.W/2 + l * (self.W/2) / (d * 0.66)
            by = hz + ((self.camera_z - wz) / d) * (self.H/2)
            pj.append((bx * Window.width / self.W, Window.height - by * Window.height / self.H, d))
        dcx = cx - self.px; dcy = cy - self.py
        dc = dcx * cos_a + dcy * sin_a
        lc = -dcx * sin_a + dcy * cos_a
        if dc > 0.15:
            bxc = self.W/2 + lc * (self.W/2) / (dc * 0.66)
            ci = int(bxc / self.RAY_WIDTH)
            if 0 <= ci < self.NUM_RAYS and self.wall_dists[ci] < dc - 0.3: return
        flist = []
        for i, f in enumerate(faces):
            p1, p2, p3 = pj[f[0]], pj[f[1]], pj[f[2]]
            flist.append(((p1[2]+p2[2]+p3[2])/3, p1, p2, p3, i))
        flist.sort(key=lambda x: -x[0])
        for ad, p1, p2, p3, idx in flist:
            c = colors[idx % len(colors)]
            self.cube_group.add(Color(*c, 1))
            self.cube_group.add(Triangle(points=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]]))

    def _project(self, wx, wy, wz, clamp=False):
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        dx = wx - self.px; dy = wy - self.py
        d = dx * cos_a + dy * sin_a
        l = -dx * sin_a + dy * cos_a
        if d < 0.1:
            if clamp: d = 0.1
            else: return None
        bx = self.W/2 + l * (self.W/2) / (d * 0.66)
        by = hz + ((self.camera_z - wz) / d) * (self.H/2)
        return (bx * Window.width / self.W, Window.height - by * Window.height / self.H, d)

    def _add_wall_poly(self, polys, x1, y1, x2, y2, z0, z1, col):
        p1 = self._project(x1, y1, z0)
        p2 = self._project(x2, y2, z0)
        p3 = self._project(x2, y2, z1)
        p4 = self._project(x1, y1, z1)
        if p1 and p2 and p3 and p4:
            avg_d = (p1[2] + p2[2] + p3[2] + p4[2]) / 4
            polys.append((avg_d, [p4, p3, p2, p1], col))

    def render_3d_polygons(self):
        self.floor_group.clear()
        polys = []
        cx, cy = int(self.px), int(self.py)
        radius = 10

        for i in range(max(0, cy-radius), min(self.MS, cy+radius+1)):
            for j in range(max(0, cx-radius), min(self.MS, cx+radius+1)):
                tile = self.MAP[i][j]
                
                if tile == 1:
                    z0 = BASE_FLOOR
                    z1 = BASE_FLOOR + self.WALL_H[i][j]
                    if i > 0 and self.MAP[i-1][j] != 1:
                        self._add_wall_poly(polys, j, i, j+1, i, z0, z1, (0.7,0.7,0.7,1))
                    if i < self.MS-1 and self.MAP[i+1][j] != 1:
                        self._add_wall_poly(polys, j+1, i+1, j, i+1, z0, z1, (0.5,0.5,0.5,1))
                    if j < self.MS-1 and self.MAP[i][j+1] != 1:
                        self._add_wall_poly(polys, j+1, i, j+1, i+1, z0, z1, (0.4,0.4,0.4,1))
                    if j > 0 and self.MAP[i][j-1] != 1:
                        self._add_wall_poly(polys, j, i+1, j, i, z0, z1, (0.6,0.6,0.6,1))
                    continue

                z = self.FLOOR_Z[i][j]
                is_ramp = (self.RAMPS[i][j] == 1) if hasattr(self, 'RAMPS') else False
                
                if is_ramp:
                    c1 = self._project(j, i, z)
                    c2 = self._project(j+1, i, z + 1.0)
                    c3 = self._project(j+1, i+1, z + 1.0)
                    c4 = self._project(j, i+1, z)
                    col = (0.5, 0.8, 0.5, 1)
                else:
                    c1 = self._project(j, i, z)
                    c2 = self._project(j+1, i, z)
                    c3 = self._project(j+1, i+1, z)
                    c4 = self._project(j, i+1, z)
                    
                    if tile == 6: col = (0.0, 0.5, 1.0, 1) # Синий
                    elif tile == 7: col = (0.0, 1.0, 0.0, 1) # Зеленый
                    elif tile == 8: col = (1.0, 0.0, 0.0, 1) # Красный
                    else:
                        if abs(z - BASE_FLOOR) < 0.01: col = (0.56, 0.44, 0.31, 1)
                        elif z > BASE_FLOOR: col = (0.88, 0.75, 0.56, 1)
                        else: col = (0.2, 0.1, 0.05, 1)

                if c1 and c2 and c3 and c4:
                    avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                    polys.append((avg_d, [c1, c2, c3, c4], col))

                if not is_ramp:
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            nz = self.FLOOR_Z[ni][nj]
                            if abs(nz - z) > 0.01 and nz < z:
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], nz)
                                p_br = self._project(b[0], b[1], nz)
                                p_tr = self._project(b[0], b[1], z)
                                p_tl = self._project(a[0], a[1], z)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], (0.45, 0.32, 0.18, 1)))

                cz = self.CEIL_Z[i][j] if hasattr(self, 'CEIL_Z') else 0
                if cz > 0:
                    cc1 = self._project(j, i, cz)
                    cc2 = self._project(j+1, i, cz)
                    cc3 = self._project(j+1, i+1, cz)
                    cc4 = self._project(j, i+1, cz)
                    if all(p is not None for p in [cc1, cc2, cc3, cc4]):
                        cavg = (cc1[2]+cc2[2]+cc3[2]+cc4[2])/4
                        polys.append((cavg, [cc1, cc2, cc3, cc4], (0.3, 0.3, 0.4, 1)))

        polys.sort(key=lambda x: -x[0])
        for d, pts4, col in polys:
            self.floor_group.add(Color(*col))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[1][0],pts4[1][1],pts4[2][0],pts4[2][1]]))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[2][0],pts4[2][1],pts4[3][0],pts4[3][1]]))

    def draw_cube_3d(self, cx, cy, cz, ax, ay, s, colors):
        verts = [(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
        faces = [(0,1,2),(0,2,3),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(0,3,7),(0,7,4),(1,2,6),(1,6,5)]
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        rv = [rot_y(rot_x(v, ax), ay) for v in verts]
        pj = []
        for v in rv:
            wx = cx + v[0]; wy = cy + v[1]; wz = cz + v[2]
            dx = wx - self.px; dy = wy - self.py
            d = dx * cos_a + dy * sin_a
            l = -dx * sin_a + dy * cos_a
            if d < 0.15: return
            bx = self.W/2 + l * (self.W/2) / (d * 0.66)
            by = hz + ((self.camera_z - wz) / d) * (self.H/2)
            pj.append((bx * Window.width / self.W, Window.height - by * Window.height / self.H, d))
        dcx = cx - self.px; dcy = cy - self.py
        dc = dcx * cos_a + dcy * sin_a
        lc = -dcx * sin_a + dcy * cos_a
        if dc > 0.15:
            bxc = self.W/2 + lc * (self.W/2) / (dc * 0.66)
            ci = int(bxc / self.RAY_WIDTH)
            if 0 <= ci < self.NUM_RAYS and self.wall_dists[ci] < dc - 0.3: return
        flist = []
        for i, f in enumerate(faces):
            p1, p2, p3 = pj[f[0]], pj[f[1]], pj[f[2]]
            flist.append(((p1[2]+p2[2]+p3[2])/3, p1, p2, p3, i))
        flist.sort(key=lambda x: -x[0])
        for ad, p1, p2, p3, idx in flist:
            c = colors[idx % len(colors)]
            self.cube_group.add(Color(*c, 1))
            self.cube_group.add(Triangle(points=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]]))

    def _project(self, wx, wy, wz, clamp=False):
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        dx = wx - self.px; dy = wy - self.py
        d = dx * cos_a + dy * sin_a
        l = -dx * sin_a + dy * cos_a
        if d < 0.1:
            if clamp: d = 0.1
            else: return None
        bx = self.W/2 + l * (self.W/2) / (d * 0.66)
        by = hz + ((self.camera_z - wz) / d) * (self.H/2)
        return (bx * Window.width / self.W, Window.height - by * Window.height / self.H, d)

    def _add_wall_poly(self, polys, x1, y1, x2, y2, z0, z1, col):
        p1 = self._project(x1, y1, z0)
        p2 = self._project(x2, y2, z0)
        p3 = self._project(x2, y2, z1)
        p4 = self._project(x1, y1, z1)
        if p1 and p2 and p3 and p4:
            avg_d = (p1[2] + p2[2] + p3[2] + p4[2]) / 4
            polys.append((avg_d, [p4, p3, p2, p1], col))

    def render_3d_polygons(self):
        self.floor_group.clear()
        polys = []
        cx, cy = int(self.px), int(self.py)
        radius = 10

        for i in range(max(0, cy-radius), min(self.MS, cy+radius+1)):
            for j in range(max(0, cx-radius), min(self.MS, cx+radius+1)):
                tile = self.MAP[i][j]
                
                if tile == 1:
                    z0 = BASE_FLOOR
                    z1 = BASE_FLOOR + self.WALL_H[i][j]
                    if i > 0 and self.MAP[i-1][j] != 1:
                        self._add_wall_poly(polys, j, i, j+1, i, z0, z1, (0.7,0.7,0.7,1))
                    if i < self.MS-1 and self.MAP[i+1][j] != 1:
                        self._add_wall_poly(polys, j+1, i+1, j, i+1, z0, z1, (0.5,0.5,0.5,1))
                    if j < self.MS-1 and self.MAP[i][j+1] != 1:
                        self._add_wall_poly(polys, j+1, i, j+1, i+1, z0, z1, (0.4,0.4,0.4,1))
                    if j > 0 and self.MAP[i][j-1] != 1:
                        self._add_wall_poly(polys, j, i+1, j, i, z0, z1, (0.6,0.6,0.6,1))
                    continue

                z = self.FLOOR_Z[i][j]
                is_ramp = (self.RAMPS[i][j] == 1) if hasattr(self, 'RAMPS') else False
                
                if is_ramp:
                    c1 = self._project(j, i, z)
                    c2 = self._project(j+1, i, z + 1.0)
                    c3 = self._project(j+1, i+1, z + 1.0)
                    c4 = self._project(j, i+1, z)
                    col = (0.5, 0.8, 0.5, 1)
                else:
                    c1 = self._project(j, i, z)
                    c2 = self._project(j+1, i, z)
                    c3 = self._project(j+1, i+1, z)
                    c4 = self._project(j, i+1, z)
                    
                    # Красим дно в цвет жидкости
                    if tile == 6: col = (0.0, 0.5, 1.0, 1) # Синий (вода)
                    elif tile == 7: col = (0.0, 1.0, 0.0, 1) # Зеленый (токсины)
                    elif tile == 8: col = (1.0, 0.0, 0.0, 1) # Красный (лава)
                    else:
                        if abs(z - BASE_FLOOR) < 0.01: col = (0.56, 0.44, 0.31, 1)
                        elif z > BASE_FLOOR: col = (0.88, 0.75, 0.56, 1)
                        else: col = (0.2, 0.1, 0.05, 1)

                if c1 and c2 and c3 and c4:
                    avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                    polys.append((avg_d, [c1, c2, c3, c4], col))

                if not is_ramp:
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            nz = self.FLOOR_Z[ni][nj]
                            if abs(nz - z) > 0.01 and nz < z:
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], nz)
                                p_br = self._project(b[0], b[1], nz)
                                p_tr = self._project(b[0], b[1], z)
                                p_tl = self._project(a[0], a[1], z)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], (0.45, 0.32, 0.18, 1)))

                cz = self.CEIL_Z[i][j] if hasattr(self, 'CEIL_Z') else 0
                if cz > 0:
                    cc1 = self._project(j, i, cz)
                    cc2 = self._project(j+1, i, cz)
                    cc3 = self._project(j+1, i+1, cz)
                    cc4 = self._project(j, i+1, cz)
                    if all(p is not None for p in [cc1, cc2, cc3, cc4]):
                        cavg = (cc1[2]+cc2[2]+cc3[2]+cc4[2])/4
                        polys.append((cavg, [cc1, cc2, cc3, cc4], (0.3, 0.3, 0.4, 1)))

        polys.sort(key=lambda x: -x[0])
        for d, pts4, col in polys:
            self.floor_group.add(Color(*col))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[1][0],pts4[1][1],pts4[2][0],pts4[2][1]]))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[2][0],pts4[2][1],pts4[3][0],pts4[3][1]]))

    def draw_cube_3d(self, cx, cy, cz, ax, ay, s, colors):
        verts = [(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
        faces = [(0,1,2),(0,2,3),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(0,3,7),(0,7,4),(1,2,6),(1,6,5)]
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        rv = [rot_y(rot_x(v, ax), ay) for v in verts]
        pj = []
        for v in rv:
            wx = cx + v[0]; wy = cy + v[1]; wz = cz + v[2]
            dx = wx - self.px; dy = wy - self.py
            d = dx * cos_a + dy * sin_a
            l = -dx * sin_a + dy * cos_a
            if d < 0.15: return
            bx = self.W/2 + l * (self.W/2) / (d * 0.66)
            by = hz + ((self.camera_z - wz) / d) * (self.H/2)
            pj.append((bx * Window.width / self.W, Window.height - by * Window.height / self.H, d))
        dcx = cx - self.px; dcy = cy - self.py
        dc = dcx * cos_a + dcy * sin_a
        lc = -dcx * sin_a + dcy * cos_a
        if dc > 0.15:
            bxc = self.W/2 + lc * (self.W/2) / (dc * 0.66)
            ci = int(bxc / self.RAY_WIDTH)
            if 0 <= ci < self.NUM_RAYS and self.wall_dists[ci] < dc - 0.3: return
        flist = []
        for i, f in enumerate(faces):
            p1, p2, p3 = pj[f[0]], pj[f[1]], pj[f[2]]
            flist.append(((p1[2]+p2[2]+p3[2])/3, p1, p2, p3, i))
        flist.sort(key=lambda x: -x[0])
        for ad, p1, p2, p3, idx in flist:
            c = colors[idx % len(colors)]
            self.cube_group.add(Color(*c, 1))
            self.cube_group.add(Triangle(points=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]]))

    def _project(self, wx, wy, wz, clamp=False):
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        dx = wx - self.px; dy = wy - self.py
        d = dx * cos_a + dy * sin_a
        l = -dx * sin_a + dy * cos_a
        if d < 0.1:
            if clamp: d = 0.1
            else: return None
        bx = self.W/2 + l * (self.W/2) / (d * 0.66)
        by = hz + ((self.camera_z - wz) / d) * (self.H/2)
        return (bx * Window.width / self.W, Window.height - by * Window.height / self.H, d)

    def _add_wall_poly(self, polys, x1, y1, x2, y2, z0, z1, col):
        p1 = self._project(x1, y1, z0)
        p2 = self._project(x2, y2, z0)
        p3 = self._project(x2, y2, z1)
        p4 = self._project(x1, y1, z1)
        if p1 and p2 and p3 and p4:
            avg_d = (p1[2] + p2[2] + p3[2] + p4[2]) / 4
            polys.append((avg_d, [p4, p3, p2, p1], col))

    def render_3d_polygons(self):
        self.floor_group.clear()
        polys = []
        cx, cy = int(self.px), int(self.py)
        radius = 10

        for i in range(max(0, cy-radius), min(self.MS, cy+radius+1)):
            for j in range(max(0, cx-radius), min(self.MS, cx+radius+1)):
                tile = self.MAP[i][j]
                
                # 1. СТЕНЫ
                if tile == 1:
                    z0 = BASE_FLOOR
                    z1 = BASE_FLOOR + self.WALL_H[i][j]
                    if i > 0 and self.MAP[i-1][j] != 1:
                        self._add_wall_poly(polys, j, i, j+1, i, z0, z1, (0.7,0.7,0.7,1))
                    if i < self.MS-1 and self.MAP[i+1][j] != 1:
                        self._add_wall_poly(polys, j+1, i+1, j, i+1, z0, z1, (0.5,0.5,0.5,1))
                    if j < self.MS-1 and self.MAP[i][j+1] != 1:
                        self._add_wall_poly(polys, j+1, i, j+1, i+1, z0, z1, (0.4,0.4,0.4,1))
                    if j > 0 and self.MAP[i][j-1] != 1:
                        self._add_wall_poly(polys, j, i+1, j, i, z0, z1, (0.6,0.6,0.6,1))
                    continue

                z = self.FLOOR_Z[i][j]
                
                # 2. ЖИДКОСТИ (6 - вода, 7 - токсины, 8 - лава)
                if tile in (6, 7, 8):
                    # Поверхность жидкости на высоте 0.05
                    c1 = self._project(j, i, 0.05, clamp=True)
                    c2 = self._project(j+1, i, 0.05, clamp=True)
                    c3 = self._project(j+1, i+1, 0.05, clamp=True)
                    c4 = self._project(j, i+1, 0.05, clamp=True)
                    if c1 and c2 and c3 and c4:
                        avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                        if tile == 6: col = (0.2, 0.4, 0.9, 1) # Вода
                        elif tile == 7: col = (0.2, 0.9, 0.2, 1) # Токсины
                        else: col = (0.9, 0.1, 0.1, 1) # Лава
                        polys.append((avg_d, [c1, c2, c3, c4], col))
                    
                    # Стенки ванны с жидкостью
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            if self.MAP[ni][nj] not in (6, 7, 8):
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], z)
                                p_br = self._project(b[0], b[1], z)
                                p_tr = self._project(b[0], b[1], 0.05)
                                p_tl = self._project(a[0], a[1], 0.05)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    if tile == 6: wcol = (0.1, 0.2, 0.6, 1)
                                    elif tile == 7: wcol = (0.1, 0.6, 0.1, 1)
                                    else: wcol = (0.6, 0.0, 0.0, 1)
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], wcol))
                    continue

                # 3. ПОЛ/НАКЛОНЫ
                is_ramp = (self.RAMPS[i][j] == 1) if hasattr(self, 'RAMPS') else False
                if is_ramp:
                    c1 = self._project(j, i, z, clamp=True)
                    c2 = self._project(j+1, i, z + 1.0, clamp=True)
                    c3 = self._project(j+1, i+1, z + 1.0, clamp=True)
                    c4 = self._project(j, i+1, z, clamp=True)
                    col = (0.5, 0.8, 0.5, 1)
                else:
                    c1 = self._project(j, i, z, clamp=True)
                    c2 = self._project(j+1, i, z, clamp=True)
                    c3 = self._project(j+1, i+1, z, clamp=True)
                    c4 = self._project(j, i+1, z, clamp=True)
                    if abs(z - BASE_FLOOR) < 0.01: col = (0.56, 0.44, 0.31, 1)
                    elif z > BASE_FLOOR: col = (0.88, 0.75, 0.56, 1)
                    else: col = (0.2, 0.1, 0.05, 1)

                if c1 and c2 and c3 and c4:
                    avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                    polys.append((avg_d, [c1, c2, c3, c4], col))

                # Стенки для обычных ступеней и ям
                if not is_ramp:
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            nz = self.FLOOR_Z[ni][nj]
                            if abs(nz - z) > 0.01 and nz < z:
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], nz)
                                p_br = self._project(b[0], b[1], nz)
                                p_tr = self._project(b[0], b[1], z)
                                p_tl = self._project(a[0], a[1], z)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], (0.45, 0.32, 0.18, 1)))

                # 4. ПОТОЛОК
                cz = self.CEIL_Z[i][j] if hasattr(self, 'CEIL_Z') else 0
                if cz > 0:
                    cc1 = self._project(j, i, cz)
                    cc2 = self._project(j+1, i, cz)
                    cc3 = self._project(j+1, i+1, cz)
                    cc4 = self._project(j, i+1, cz)
                    if all(p is not None for p in [cc1, cc2, cc3, cc4]):
                        cavg = (cc1[2]+cc2[2]+cc3[2]+cc4[2])/4
                        polys.append((cavg, [cc1, cc2, cc3, cc4], (0.3, 0.3, 0.4, 1)))

        polys.sort(key=lambda x: -x[0])
        for d, pts4, col in polys:
            self.floor_group.add(Color(*col))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[1][0],pts4[1][1],pts4[2][0],pts4[2][1]]))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[2][0],pts4[2][1],pts4[3][0],pts4[3][1]]))

    def draw_cube_3d(self, cx, cy, cz, ax, ay, s, colors):
        verts = [(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
        faces = [(0,1,2),(0,2,3),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(0,3,7),(0,7,4),(1,2,6),(1,6,5)]
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        rv = [rot_y(rot_x(v, ax), ay) for v in verts]
        pj = []
        for v in rv:
            wx = cx + v[0]; wy = cy + v[1]; wz = cz + v[2]
            dx = wx - self.px; dy = wy - self.py
            d = dx * cos_a + dy * sin_a
            l = -dx * sin_a + dy * cos_a
            if d < 0.15: return
            bx = self.W/2 + l * (self.W/2) / (d * 0.66)
            by = hz + ((self.camera_z - wz) / d) * (self.H/2)
            pj.append((bx * Window.width / self.W, Window.height - by * Window.height / self.H, d))
        dcx = cx - self.px; dcy = cy - self.py
        dc = dcx * cos_a + dcy * sin_a
        lc = -dcx * sin_a + dcy * cos_a
        if dc > 0.15:
            bxc = self.W/2 + lc * (self.W/2) / (dc * 0.66)
            ci = int(bxc / self.RAY_WIDTH)
            if 0 <= ci < self.NUM_RAYS and self.wall_dists[ci] < dc - 0.3: return
        flist = []
        for i, f in enumerate(faces):
            p1, p2, p3 = pj[f[0]], pj[f[1]], pj[f[2]]
            flist.append(((p1[2]+p2[2]+p3[2])/3, p1, p2, p3, i))
        flist.sort(key=lambda x: -x[0])
        for ad, p1, p2, p3, idx in flist:
            c = colors[idx % len(colors)]
            self.cube_group.add(Color(*c, 1))
            self.cube_group.add(Triangle(points=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]]))

    def _project(self, wx, wy, wz, clamp=False):
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        dx = wx - self.px; dy = wy - self.py
        d = dx * cos_a + dy * sin_a
        l = -dx * sin_a + dy * cos_a
        if d < 0.1:
            if clamp: d = 0.1
            else: return None
        bx = self.W/2 + l * (self.W/2) / (d * 0.66)
        by = hz + ((self.camera_z - wz) / d) * (self.H/2)
        return (bx * Window.width / self.W, Window.height - by * Window.height / self.H, d)

    def _add_wall_poly(self, polys, x1, y1, x2, y2, z0, z1, col):
        p1 = self._project(x1, y1, z0)
        p2 = self._project(x2, y2, z0)
        p3 = self._project(x2, y2, z1)
        p4 = self._project(x1, y1, z1)
        if p1 and p2 and p3 and p4:
            avg_d = (p1[2] + p2[2] + p3[2] + p4[2]) / 4
            polys.append((avg_d, [p4, p3, p2, p1], col))

    def render_3d_polygons(self):
        self.floor_group.clear()
        polys = []
        cx, cy = int(self.px), int(self.py)
        radius = 10

        for i in range(max(0, cy-radius), min(self.MS, cy+radius+1)):
            for j in range(max(0, cx-radius), min(self.MS, cx+radius+1)):
                tile = self.MAP[i][j]
                
                # 1. СТЕНЫ
                if tile == 1:
                    z0 = BASE_FLOOR
                    z1 = BASE_FLOOR + self.WALL_H[i][j]
                    if i > 0 and self.MAP[i-1][j] != 1:
                        self._add_wall_poly(polys, j, i, j+1, i, z0, z1, (0.7,0.7,0.7,1))
                    if i < self.MS-1 and self.MAP[i+1][j] != 1:
                        self._add_wall_poly(polys, j+1, i+1, j, i+1, z0, z1, (0.5,0.5,0.5,1))
                    if j < self.MS-1 and self.MAP[i][j+1] != 1:
                        self._add_wall_poly(polys, j+1, i, j+1, i+1, z0, z1, (0.4,0.4,0.4,1))
                    if j > 0 and self.MAP[i][j-1] != 1:
                        self._add_wall_poly(polys, j, i+1, j, i, z0, z1, (0.6,0.6,0.6,1))
                    continue

                z = self.FLOOR_Z[i][j]
                is_ramp = (self.RAMPS[i][j] == 1) if hasattr(self, 'RAMPS') else False
                
                # 2. ЖИДКОСТИ
                is_liquid = tile in (6, 7, 8)
                # Если это просто глубокая яма - считаем её водой
                if tile == 3 and self.FLOOR_Z[i][j] < -0.7:
                    is_liquid = True
                    tile = 6  # Принудительно вода
                if is_liquid:
                    # Поверхность жидкости (на высоте 0.05, чтобы не сливаться с полом)
                    c1 = self._project(j, i, 0.05, clamp=True)
                    c2 = self._project(j+1, i, 0.05, clamp=True)
                    c3 = self._project(j+1, i+1, 0.05, clamp=True)
                    c4 = self._project(j, i+1, 0.05, clamp=True)
                    if c1 and c2 and c3 and c4:
                        avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                        if tile == 6: col = (0.1, 0.3, 1.0, 1.0) # Вода
                        elif tile == 7: col = (0.1, 1.0, 0.1, 1.0) # Токсины
                        else: col = (1.0, 0.0, 0.0, 1.0) # Лава
                        polys.append((avg_d, [c1, c2, c3, c4], col))
                    
                    # Стенки ямы с жидкостью (от дна до поверхности)
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            if self.MAP[ni][nj] not in (6, 7, 8):
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], z)
                                p_br = self._project(b[0], b[1], z)
                                p_tr = self._project(b[0], b[1], 0.05)
                                p_tl = self._project(a[0], a[1], 0.05)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    if tile == 6: wcol = (0.0, 0.1, 0.4, 1)
                                    elif tile == 7: wcol = (0.0, 0.4, 0.0, 1)
                                    else: wcol = (0.4, 0.0, 0.0, 1)
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], wcol))

                # 3. ПОЛ/НАКЛОНЫ/ДНО
                if is_ramp:
                    c1 = self._project(j, i, z, clamp=True)
                    c2 = self._project(j+1, i, z + 1.0, clamp=True)
                    c3 = self._project(j+1, i+1, z + 1.0, clamp=True)
                    c4 = self._project(j, i+1, z, clamp=True)
                    col = (0.5, 0.8, 0.5, 1)
                else:
                    c1 = self._project(j, i, z, clamp=True)
                    c2 = self._project(j+1, i, z, clamp=True)
                    c3 = self._project(j+1, i+1, z, clamp=True)
                    c4 = self._project(j, i+1, z, clamp=True)
                    if abs(z - BASE_FLOOR) < 0.01: col = (0.56, 0.44, 0.31, 1)
                    elif z > BASE_FLOOR: col = (0.88, 0.75, 0.56, 1)
                    else: col = (0.2, 0.1, 0.05, 1)

                if c1 and c2 and c3 and c4:
                    if c1[2] == 0.1 or c2[2] == 0.1 or c3[2] == 0.1 or c4[2] == 0.1:
                        avg_d = 999.0
                    else:
                        avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                    polys.append((avg_d, [c1, c2, c3, c4], col))

                # Стенки для обычных ям и ступеней (не жидкостей)
                if not is_ramp and not is_liquid:
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            if self.MAP[ni][nj] in (6,7,8): continue
                            nz = self.FLOOR_Z[ni][nj]
                            if abs(nz - z) > 0.01 and nz < z:
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], nz)
                                p_br = self._project(b[0], b[1], nz)
                                p_tr = self._project(b[0], b[1], z)
                                p_tl = self._project(a[0], a[1], z)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], (0.45, 0.32, 0.18, 1)))

                # 4. ПОТОЛОК
                cz = self.CEIL_Z[i][j] if hasattr(self, 'CEIL_Z') else 0
                if cz > 0:
                    cc1 = self._project(j, i, cz)
                    cc2 = self._project(j+1, i, cz)
                    cc3 = self._project(j+1, i+1, cz)
                    cc4 = self._project(j, i+1, cz)
                    if all(p is not None for p in [cc1, cc2, cc3, cc4]):
                        cavg = (cc1[2]+cc2[2]+cc3[2]+cc4[2])/4
                        polys.append((cavg, [cc1, cc2, cc3, cc4], (0.3, 0.3, 0.4, 1)))

        polys.sort(key=lambda x: -x[0])
        for d, pts4, col in polys:
            self.floor_group.add(Color(*col))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[1][0],pts4[1][1],pts4[2][0],pts4[2][1]]))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[2][0],pts4[2][1],pts4[3][0],pts4[3][1]]))

    def draw_cube_3d(self, cx, cy, cz, ax, ay, s, colors):
        verts = [(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
        faces = [(0,1,2),(0,2,3),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(0,3,7),(0,7,4),(1,2,6),(1,6,5)]
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        rv = [rot_y(rot_x(v, ax), ay) for v in verts]
        pj = []
        for v in rv:
            wx = cx + v[0]; wy = cy + v[1]; wz = cz + v[2]
            dx = wx - self.px; dy = wy - self.py
            d = dx * cos_a + dy * sin_a
            l = -dx * sin_a + dy * cos_a
            if d < 0.15: return
            bx = self.W/2 + l * (self.W/2) / (d * 0.66)
            by = hz + ((self.camera_z - wz) / d) * (self.H/2)
            pj.append((bx * Window.width / self.W, Window.height - by * Window.height / self.H, d))
        dcx = cx - self.px; dcy = cy - self.py
        dc = dcx * cos_a + dcy * sin_a
        lc = -dcx * sin_a + dcy * cos_a
        if dc > 0.15:
            bxc = self.W/2 + lc * (self.W/2) / (dc * 0.66)
            ci = int(bxc / self.RAY_WIDTH)
            if 0 <= ci < self.NUM_RAYS and self.wall_dists[ci] < dc - 0.3: return
        flist = []
        for i, f in enumerate(faces):
            p1, p2, p3 = pj[f[0]], pj[f[1]], pj[f[2]]
            flist.append(((p1[2]+p2[2]+p3[2])/3, p1, p2, p3, i))
        flist.sort(key=lambda x: -x[0])
        for ad, p1, p2, p3, idx in flist:
            c = colors[idx % len(colors)]
            self.cube_group.add(Color(*c, 1))
            self.cube_group.add(Triangle(points=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]]))

    def _project(self, wx, wy, wz, clamp=False):
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        dx = wx - self.px; dy = wy - self.py
        d = dx * cos_a + dy * sin_a
        l = -dx * sin_a + dy * cos_a
        if d < 0.1:
            if clamp: d = 0.1
            else: return None
        bx = self.W/2 + l * (self.W/2) / (d * 0.66)
        by = hz + ((self.camera_z - wz) / d) * (self.H/2)
        return (bx * Window.width / self.W, Window.height - by * Window.height / self.H, d)

    def _add_wall_poly(self, polys, x1, y1, x2, y2, z0, z1, col):
        p1 = self._project(x1, y1, z0)
        p2 = self._project(x2, y2, z0)
        p3 = self._project(x2, y2, z1)
        p4 = self._project(x1, y1, z1)
        if p1 and p2 and p3 and p4:
            avg_d = (p1[2] + p2[2] + p3[2] + p4[2]) / 4
            polys.append((avg_d, [p4, p3, p2, p1], col))

    def render_3d_polygons(self):
        self.floor_group.clear()
        polys = []
        cx, cy = int(self.px), int(self.py)
        radius = 10

        for i in range(max(0, cy-radius), min(self.MS, cy+radius+1)):
            for j in range(max(0, cx-radius), min(self.MS, cx+radius+1)):
                tile = self.MAP[i][j]
                
                # 1. СТЕНЫ
                if tile == 1:
                    z0 = BASE_FLOOR
                    z1 = BASE_FLOOR + self.WALL_H[i][j]
                    if i > 0 and self.MAP[i-1][j] != 1:
                        self._add_wall_poly(polys, j, i, j+1, i, z0, z1, (0.7,0.7,0.7,1))
                    if i < self.MS-1 and self.MAP[i+1][j] != 1:
                        self._add_wall_poly(polys, j+1, i+1, j, i+1, z0, z1, (0.5,0.5,0.5,1))
                    if j < self.MS-1 and self.MAP[i][j+1] != 1:
                        self._add_wall_poly(polys, j+1, i, j+1, i+1, z0, z1, (0.4,0.4,0.4,1))
                    if j > 0 and self.MAP[i][j-1] != 1:
                        self._add_wall_poly(polys, j, i+1, j, i, z0, z1, (0.6,0.6,0.6,1))
                    continue

                z = self.FLOOR_Z[i][j]
                is_ramp = (self.RAMPS[i][j] == 1) if hasattr(self, 'RAMPS') else False
                
                # 2. ЖИДКОСТИ (Вода, Токсины, Лава)
                is_liquid = tile in (6, 7, 8)
                # Если это просто глубокая яма - считаем её водой
                if tile == 3 and self.FLOOR_Z[i][j] < -0.7:
                    is_liquid = True
                    tile = 6  # Принудительно вода
                if is_liquid:
                    # Поверхность жидкости (на высоте 0.0)
                    c1 = self._project(j, i, 0.0, clamp=True)
                    c2 = self._project(j+1, i, 0.0, clamp=True)
                    c3 = self._project(j+1, i+1, 0.0, clamp=True)
                    c4 = self._project(j, i+1, 0.0, clamp=True)
                    if c1 and c2 and c3 and c4:
                        avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                        if tile == 6: col = (0.2, 0.4, 0.9, 0.8) # Вода
                        elif tile == 7: col = (0.2, 0.9, 0.2, 0.8) # Токсины
                        else: col = (0.9, 0.1, 0.1, 0.9) # Лава
                        polys.append((avg_d, [c1, c2, c3, c4], col))
                    
                    # Стенки жидкости (если сосед не жидкость)
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            if self.MAP[ni][nj] not in (6, 7, 8):
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], z)
                                p_br = self._project(b[0], b[1], z)
                                p_tr = self._project(b[0], b[1], 0.0)
                                p_tl = self._project(a[0], a[1], 0.0)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    if tile == 6: wcol = (0.1, 0.2, 0.5, 1)
                                    elif tile == 7: wcol = (0.1, 0.5, 0.1, 1)
                                    else: wcol = (0.5, 0.0, 0.0, 1)
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], wcol))

                # 3. ПОЛ/НАКЛОНЫ/ЯМЫ
                if is_ramp:
                    c1 = self._project(j, i, z, clamp=True)
                    c2 = self._project(j+1, i, z + 1.0, clamp=True)
                    c3 = self._project(j+1, i+1, z + 1.0, clamp=True)
                    c4 = self._project(j, i+1, z, clamp=True)
                    col = (0.5, 0.8, 0.5, 1)
                else:
                    c1 = self._project(j, i, z, clamp=True)
                    c2 = self._project(j+1, i, z, clamp=True)
                    c3 = self._project(j+1, i+1, z, clamp=True)
                    c4 = self._project(j, i+1, z, clamp=True)
                    if abs(z - BASE_FLOOR) < 0.01: col = (0.56, 0.44, 0.31, 1)
                    elif z > BASE_FLOOR: col = (0.88, 0.75, 0.56, 1)
                    else: col = (0.2, 0.1, 0.05, 1)

                if c1 and c2 and c3 and c4:
                    if c1[2] == 0.1 or c2[2] == 0.1 or c3[2] == 0.1 or c4[2] == 0.1:
                        avg_d = 999.0
                    else:
                        avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                    polys.append((avg_d, [c1, c2, c3, c4], col))

                # Стенки между разными уровнями (ступени/ямы)
                if not is_ramp and not is_liquid:
                    neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                    edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                    for k, (ni, nj) in enumerate(neighbors):
                        if 0 <= ni < self.MS and 0 <= nj < self.MS:
                            if self.MAP[ni][nj] in (6,7,8): continue
                            nz = self.FLOOR_Z[ni][nj]
                            if abs(nz - z) > 0.01 and nz < z:
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], nz)
                                p_br = self._project(b[0], b[1], nz)
                                p_tr = self._project(b[0], b[1], z)
                                p_tl = self._project(a[0], a[1], z)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], (0.45, 0.32, 0.18, 1)))

                # 4. ПОТОЛОК
                cz = self.CEIL_Z[i][j] if hasattr(self, 'CEIL_Z') else 0
                if cz > 0:
                    cc1 = self._project(j, i, cz)
                    cc2 = self._project(j+1, i, cz)
                    cc3 = self._project(j+1, i+1, cz)
                    cc4 = self._project(j, i+1, cz)
                    if all(p is not None for p in [cc1, cc2, cc3, cc4]):
                        cavg = (cc1[2]+cc2[2]+cc3[2]+cc4[2])/4
                        polys.append((cavg, [cc1, cc2, cc3, cc4], (0.3, 0.3, 0.4, 1)))

        polys.sort(key=lambda x: -x[0])
        for d, pts4, col in polys:
            self.floor_group.add(Color(*col))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[1][0],pts4[1][1],pts4[2][0],pts4[2][1]]))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[2][0],pts4[2][1],pts4[3][0],pts4[3][1]]))

    def draw_cube_3d(self, cx, cy, cz, ax, ay, s, colors):
        verts = [(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
        faces = [(0,1,2),(0,2,3),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(0,3,7),(0,7,4),(1,2,6),(1,6,5)]
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        rv = [rot_y(rot_x(v, ax), ay) for v in verts]
        pj = []
        for v in rv:
            wx = cx + v[0]; wy = cy + v[1]; wz = cz + v[2]
            dx = wx - self.px; dy = wy - self.py
            d = dx * cos_a + dy * sin_a
            l = -dx * sin_a + dy * cos_a
            if d < 0.15: return
            bx = self.W/2 + l * (self.W/2) / (d * 0.66)
            by = hz + ((self.camera_z - wz) / d) * (self.H/2)
            pj.append((bx * Window.width / self.W, Window.height - by * Window.height / self.H, d))
        dcx = cx - self.px; dcy = cy - self.py
        dc = dcx * cos_a + dcy * sin_a
        lc = -dcx * sin_a + dcy * cos_a
        if dc > 0.15:
            bxc = self.W/2 + lc * (self.W/2) / (dc * 0.66)
            ci = int(bxc / self.RAY_WIDTH)
            if 0 <= ci < self.NUM_RAYS and self.wall_dists[ci] < dc - 0.3: return
        flist = []
        for i, f in enumerate(faces):
            p1, p2, p3 = pj[f[0]], pj[f[1]], pj[f[2]]
            flist.append(((p1[2]+p2[2]+p3[2])/3, p1, p2, p3, i))
        flist.sort(key=lambda x: -x[0])
        for ad, p1, p2, p3, idx in flist:
            c = colors[idx % len(colors)]
            self.cube_group.add(Color(*c, 1))
            self.cube_group.add(Triangle(points=[p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]]))

    def _project(self, wx, wy, wz, clamp=False):
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        hz = self.H // 2 + self.pitch
        dx = wx - self.px; dy = wy - self.py
        d = dx * cos_a + dy * sin_a
        l = -dx * sin_a + dy * cos_a
        if d < 0.1:
            if clamp: d = 0.1
            else: return None
        bx = self.W/2 + l * (self.W/2) / (d * 0.66)
        by = hz + ((self.camera_z - wz) / d) * (self.H/2)
        return (bx * Window.width / self.W, Window.height - by * Window.height / self.H, d)

    def _add_wall_poly(self, polys, x1, y1, x2, y2, z0, z1, col):
        p1 = self._project(x1, y1, z0)
        p2 = self._project(x2, y2, z0)
        p3 = self._project(x2, y2, z1)
        p4 = self._project(x1, y1, z1)
        if p1 and p2 and p3 and p4:
            avg_d = (p1[2] + p2[2] + p3[2] + p4[2]) / 4
            polys.append((avg_d, [p4, p3, p2, p1], col))

    def render_3d_polygons(self):
        self.floor_group.clear()
        polys = []
        cx, cy = int(self.px), int(self.py)
        radius = 10

        for i in range(max(0, cy-radius), min(self.MS, cy+radius+1)):
            for j in range(max(0, cx-radius), min(self.MS, cx+radius+1)):
                if self.MAP[i][j] == 1:
                    z0 = BASE_FLOOR
                    z1 = BASE_FLOOR + self.WALL_H[i][j]
                    if i > 0 and self.MAP[i-1][j] != 1:
                        self._add_wall_poly(polys, j, i, j+1, i, z0, z1, (0.7,0.7,0.7,1))
                    if i < self.MS-1 and self.MAP[i+1][j] != 1:
                        self._add_wall_poly(polys, j+1, i+1, j, i+1, z0, z1, (0.5,0.5,0.5,1))
                    if j < self.MS-1 and self.MAP[i][j+1] != 1:
                        self._add_wall_poly(polys, j+1, i, j+1, i+1, z0, z1, (0.4,0.4,0.4,1))
                    if j > 0 and self.MAP[i][j-1] != 1:
                        self._add_wall_poly(polys, j, i+1, j, i, z0, z1, (0.6,0.6,0.6,1))
                    continue

                z = self.FLOOR_Z[i][j]
                if abs(z - BASE_FLOOR) < 0.01: col = (0.56, 0.44, 0.31, 1)
                elif z > BASE_FLOOR: col = (0.88, 0.75, 0.56, 1)
                else: col = (0.2, 0.1, 0.05, 1)

                c1 = self._project(j, i, z, clamp=True)
                c2 = self._project(j+1, i, z, clamp=True)
                c3 = self._project(j+1, i+1, z, clamp=True)
                c4 = self._project(j, i+1, z, clamp=True)
                if c1 and c2 and c3 and c4:
                    if c1[2] == 0.1 or c2[2] == 0.1 or c3[2] == 0.1 or c4[2] == 0.1:
                        avg_d = 999.0
                    else:
                        avg_d = (c1[2]+c2[2]+c3[2]+c4[2])/4
                    polys.append((avg_d, [c1, c2, c3, c4], col))

                neighbors = [(i-1,j), (i,j+1), (i+1,j), (i,j-1)]
                edges = [((j,i),(j+1,i)), ((j+1,i),(j+1,i+1)), ((j+1,i+1),(j,i+1)), ((j,i+1),(j,i))]
                for k, (ni, nj) in enumerate(neighbors):
                    if 0 <= ni < self.MS and 0 <= nj < self.MS:
                        nz = self.FLOOR_Z[ni][nj]
                        if abs(nz - z) > 0.01:
                            if nz < z:
                                a, b = edges[k]
                                p_bl = self._project(a[0], a[1], nz)
                                p_br = self._project(b[0], b[1], nz)
                                p_tr = self._project(b[0], b[1], z)
                                p_tl = self._project(a[0], a[1], z)
                                if all(p is not None for p in [p_bl,p_br,p_tr,p_tl]):
                                    face_d = (p_bl[2]+p_br[2]+p_tr[2]+p_tl[2])/4
                                    polys.append((face_d, [p_tl, p_tr, p_br, p_bl], (0.45, 0.32, 0.18, 1)))

                cz = self.CEIL_Z[i][j]
                if cz > 0:
                    cc1 = self._project(j, i, cz)
                    cc2 = self._project(j+1, i, cz)
                    cc3 = self._project(j+1, i+1, cz)
                    cc4 = self._project(j, i+1, cz)
                    if all(p is not None for p in [cc1, cc2, cc3, cc4]):
                        cavg = (cc1[2]+cc2[2]+cc3[2]+cc4[2])/4
                        polys.append((cavg, [cc1, cc2, cc3, cc4], (0.3, 0.3, 0.4, 1)))

        polys.sort(key=lambda x: -x[0])
        for d, pts4, col in polys:
            self.floor_group.add(Color(*col))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[1][0],pts4[1][1],pts4[2][0],pts4[2][1]]))
            self.floor_group.add(Triangle(points=[pts4[0][0],pts4[0][1],pts4[2][0],pts4[2][1],pts4[3][0],pts4[3][1]]))


    def draw_npc(self, npc):
        if not npc['alive']: return
        cos_a = math.cos(self.angle); sin_a = math.sin(self.angle)
        dx = npc['x'] - self.px; dy = npc['y'] - self.py
        d = dx * cos_a + dy * sin_a
        l = -dx * sin_a + dy * cos_a
        if d < 0.2: return
        bxc = self.W / 2 + l * (self.W/2) / (d * 0.66)
        hz = self.H // 2 + self.pitch
        npc_floor = self.FLOOR_Z[int(npc['y'])][int(npc['x'])]
        feet = hz + ((self.camera_z - npc_floor) / d) * (self.H / 2)
        head = hz + ((self.camera_z - (npc_floor + 0.8)) / d) * (self.H / 2)
        w_world = 0.5
        wpx = (w_world / d) * (self.W / 2) / 0.66
        cx_screen = bxc * Window.width / self.W
        wpx_s = wpx * Window.width / self.W
        x1 = cx_screen - wpx_s; x2 = cx_screen + wpx_s
        y_feet = Window.height - (feet * Window.height / self.H)
        y_head = Window.height - (head * Window.height / self.H)
        c = npc['color']
        self.cube_group.add(Color(*c, 1))
        self.cube_group.add(Triangle(points=[x1, y_feet, x2, y_feet, x2, y_head]))
        self.cube_group.add(Triangle(points=[x1, y_feet, x2, y_head, x1, y_head]))

    def update(self, dt):
        if not self.is_running: return
        try:
            if self.is_networked and not self.is_server_host:
                self.net_client.send({"type": "input", "fwd": self.mdy, "strafe": self.mdx, "angle": self.angle, "pitch": self.pitch})
                while not net_queue.empty():
                    msg = net_queue.get()
                    if msg["type"] == "state":
                        self.my_id = msg["my_id"]
                        if not self.dead:
                            self.px = msg["players"][str(self.my_id)]["x"]
                            self.py = msg["players"][str(self.my_id)]["y"]
                            self.health = msg["players"][str(self.my_id)]["health"]
                        self.other_players = {k: v for k, v in msg["players"].items() if k != str(self.my_id)}
                    elif msg["type"] == "chat":
                        self.chat_messages.append(f"{msg['nick']}: {msg['text']}")
                        self.chat_timer = 8.0; self.update_chat()
            else:
                self.update_cube_physics(dt)
                self.update_spawned_cubes(dt)
                
                if not self.dead:
                    sp = 3.0 * dt
                    nx = self.px + (math.cos(self.angle)*self.mdy - math.sin(self.angle)*self.mdx) * sp
                    ny = self.py + (math.sin(self.angle)*self.mdy + math.cos(self.angle)*self.mdx) * sp
                    if self.can_move(nx, self.py): self.px = nx
                    if self.can_move(self.px, ny): self.py = ny
                    
                    fh = self.FLOOR_Z[int(self.py)][int(self.px)]
                    if not self.cube_holding:
                        if abs(self.cube_x - self.px) < self.cube_size*1.4 and abs(self.cube_y - self.py) < self.cube_size*1.4:
                            ct = self.cube_z + self.cube_size
                            pb = self.camera_z - self.base_eye
                            if pb >= ct - 0.15: fh = max(fh, ct)
                    for c in self.spawned_cubes:
                        if abs(c['x'] - self.px) < c['size']*1.4 and abs(c['y'] - self.py) < c['size']*1.4:
                            ct = c['z'] + c['size']
                            pb = self.camera_z - self.base_eye
                            if pb >= ct - 0.15: fh = max(fh, ct)

                    tz = fh + self.base_eye
                    if self.jumping:
                        self.camera_z += self.jump_vy * dt
                        self.jump_vy -= 0.04 * dt
                        if self.camera_z <= tz and self.jump_vy < 0:
                            self.camera_z = tz; self.jumping = False; self.jump_vy = 0
                    else:
                        self.camera_z += (tz - self.camera_z) * 10 * dt

                    if self.is_server_host and self.net_server:
                        self.net_server.broadcast({"type": "state", "my_id": 0, "players": {"0": {"x": self.px, "y": self.py, "health": self.health}}})
                        
                    # --- ЛОГИКА ЖИДКОСТЕЙ ---
                    t_x, t_y = int(self.px), int(self.py)
                    if 0 <= t_x < self.MS and 0 <= t_y < self.MS:
                        tile = self.MAP[t_y][t_x]
                        if tile == 6: # Вода
                            self.drown_timer += dt
                            if self.drown_timer > 20.0 and getattr(self, 'damage_cooldown', 0) <= 0:
                                self.health = max(0, self.health - random.randint(5, 10))
                                self.chat_messages.append(f"УДУШЕНИЕ! HP: {self.health}")
                                self.chat_timer = 1.0; self.update_chat(); self.damage_cooldown = 1.0
                        elif tile in (7, 8): # Токсины / Лава
                            self.drown_timer = 0
                            if getattr(self, 'damage_cooldown', 0) <= 0:
                                dmg = random.randint(10, 20) if tile == 7 else random.randint(50, 60)
                                self.health = max(0, self.health - dmg)
                                self.chat_messages.append(f"{'ТОКСИНЫ' if tile==7 else 'ЛАВА'}! HP: {self.health}")
                                self.chat_timer = 1.0; self.update_chat(); self.damage_cooldown = 1.0
                        else:
                            self.drown_timer = 0
                    
                    if getattr(self, 'damage_cooldown', 0) > 0: self.damage_cooldown -= dt

                    if self.health <= 0:
                        self.dead = True
                        self.btn_respawn.opacity = 1
                        self.btn_respawn.disabled = False
                        self.chat_messages.append("ВЫ ПОГИБЛИ!")
                        self.update_chat()

            if self.chat_timer > 0:
                self.chat_timer -= dt
                if self.chat_timer <= 0:
                    self.chat_messages = self.chat_messages[-3:]; self.update_chat()

            if self.shooting: self.recoil = 1.0; self.shooting = False
            else: self.recoil *= 0.8
            rp = self.recoil * 30
            self.gb.pos = (Window.width/2-40, -20-rp); self.br2.pos = (Window.width/2-10, 100-rp)
            if self.recoil > 0.8: self.bc.rgba = (1,1,0,1)
            else: self.bc.rgba = (0.1,0.1,0.1,1)

            self.render_3d_polygons()
            
            self.cube_group.clear()
            if self.app.hud_visible and not self.dead:
                for c in self.spawned_cubes:
                    col = c['color']
                    self.draw_cube_3d(c['x'], c['y'], c['z'], c['ax'], c['ay'], c['size'], [col]*6 + [tuple(v*0.6 for v in col)]*6)
                self.draw_cube_3d(self.cube_x, self.cube_y, self.cube_z, self.cube_ax, self.cube_ay, self.cube_size, [(0.9,0.3,0.3),(0.6,0.15,0.15),(0.5,0.1,0.1),(1.0,0.6,0.6),(0.8,0.25,0.25),(0.7,0.2,0.2)])
                for npc in self.npcs:
                    self.draw_npc(npc)
            
            self.fl.text = f"{self.nick} | HP: {self.health} | FPS: {self.frames}"
            self.fl.opacity = 1 if self.app.hud_visible else 0
            self.jl.opacity = 1 if self.app.hud_visible else 0
            self.pl.opacity = 1 if self.app.hud_visible else 0
            self.sl.opacity = 1 if self.app.hud_visible else 0
            
            self.frames += 1
            now = Clock.get_time()
            if now - self.ltime >= 1.0:
                self.frames = 0; self.ltime = now
        except Exception as e:
            import traceback; traceback.print_exc()
            self.fl.color = (1,0,0,1)
            self.fl.text = f"ERR: {str(e)[:40]}"
    def build(self):
        self.screen_res = (800, 400)
        self.res = (120, 80)
        self.fps_limit = 30
        self.nick = "Player"
        self.port = 5555
        self.server_ip = "127.0.0.1"
        self.multiplayer_mode = None
        self.hud_visible = True
        self.hud_scale = 1.0
        self.sm = ScreenManager()
        self.sm.add_widget(MainMenu(self, name='menu'))
        self.sm.add_widget(PlayModeScreen(self, name='play'))
        self.sm.add_widget(MultiplayerMenu(self, name='mp'))
        self.sm.add_widget(SettingsScreen(self, name='settings'))
        self.sm.add_widget(MapSelectScreen(self, name='map_select'))
        self.sm.add_widget(GameScreen(self, name='game'))
        return self.sm
    def apply_screen_res(self):
        try:
            w, h = self.screen_res
            Window.size = (w, h)
            if Window.system_size[0] > w and Window.system_size[1] > h:
                Window.left = int((Window.system_size[0] - w) / 2)
                Window.top = int((Window.system_size[1] - h) / 2)
        except Exception as e:
            print(f"Window error: {e}")
    def show_menu(self): self.sm.current = 'menu'
    def show_map_select(self): self.sm.current = 'map_select'
    def show_play_menu(self): self.sm.current = 'play'
    def show_mp_menu(self): self.sm.current = 'mp'
    def show_settings(self): self.sm.current = 'settings'
    def start_single(self):
        self.multiplayer_mode = None; self.sm.current = 'game'
    def start_server_game(self):
        self.multiplayer_mode = "server"; self.sm.current = 'game'
    def start_custom_game(self):
        self.multiplayer_mode = "custom"; self.sm.current = 'game'
    def load_map(self, path, *args):
        print(f"ENGINE: Получен путь: {path}")
        self.custom_map_path = path
        self.multiplayer_mode = "custom"
        self.sm.current = 'game'

    def start_client_game(self, ip):
        self.multiplayer_mode = "client"; self.server_ip = ip; self.sm.current = 'game'



class EngineApp(App):
    def build(self):
        self.screen_res = (800, 400)
        self.res = (120, 80)
        self.fps_limit = 30
        self.nick = "Player"
        self.port = 5555
        self.server_ip = "127.0.0.1"
        self.multiplayer_mode = None
        self.hud_visible = True
        self.hud_scale = 1.0
        
        self.sm = ScreenManager()
        self.sm.add_widget(MainMenu(self, name='menu'))
        self.sm.add_widget(PlayModeScreen(self, name='play'))
        self.sm.add_widget(MultiplayerMenu(self, name='mp'))
        self.sm.add_widget(SettingsScreen(self, name='sett